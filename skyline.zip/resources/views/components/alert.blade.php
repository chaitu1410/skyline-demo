<div id="toastmsg" class="alert alert-{{ $type }} alert-dismissible" role="alert">
    <p class="mb-0">{{ $slot }}</p>
    <button type="button" class="btn btn-sm" data-bs-dismiss="alert" aria-label="Close">
        <span class="material-icons">
            close
        </span>
    </button>
</div>