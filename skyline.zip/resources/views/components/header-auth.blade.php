<div>
    <!-- header - navigation bar start-->
    <section>
        <nav class="navbar navbar-expand-lg navbar-dark bluebg" aria-label="Main navigation">
            <div class="container-fluid">

                <!-- logo -->
                <a id="sky-logo" class="navbar-brand mr-auto" onclick="location.href='{{ route('home') }}'">
                    <img src="assets/images/logo.png" alt="logo" height="24" class="d-inline-block align-text-top">
                </a>
                <!-- logo end -->

            </div>
        </nav>
    </section>
    <!-- header - navigation bar end -->
</div>