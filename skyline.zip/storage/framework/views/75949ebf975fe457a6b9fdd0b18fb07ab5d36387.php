

<?php $__env->startSection('ogtitle', 'Skyline Distributors | Aurangabad'); ?>
<?php $__env->startSection('title', 'Skyline Distributors | Aurangabad - Products'); ?>

<?php $__env->startSection('content'); ?>

<!-- breadcrumb start -->
<nav id="breadcrumbproductinfo" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb" class="pb-0">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
        <li class="breadcrumb-item"><a href="allcategories.html">Products</a></li>
    </ol>
</nav>
<!-- breadcrumb ends -->

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('product-list', ['query' => $query])->html();
} elseif ($_instance->childHasBeenRendered('WPhgpFC')) {
    $componentId = $_instance->getRenderedChildComponentId('WPhgpFC');
    $componentTag = $_instance->getRenderedChildComponentTagName('WPhgpFC');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('WPhgpFC');
} else {
    $response = \Livewire\Livewire::mount('product-list', ['query' => $query]);
    $html = $response->html();
    $_instance->logRenderedChild('WPhgpFC', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<!-- filter sidebar ends -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['header' => 'full', 'footer' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adina\Desktop\skyline\resources\views/products/index.blade.php ENDPATH**/ ?>