<form action="<?php echo e(route('admin.pincodes.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="modal-body">
        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">State
                Name</label>
            <select id="states" name="state" class="form-select form-select-sm" aria-label=".form-select-sm example" wire:model="selectedState">
                <option value="-1">Open this select menu</option>
                <?php $__empty_1 = true; $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <option value="<?php echo e($state['name']); ?>"><?php echo e($state['name']); ?></option>    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    
                <?php endif; ?>
            </select>
        </div>
        <?php if($selectedState): ?>     
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">City
                    Name</label>
                <select id="cities" name="city" class="form-select form-select-sm" aria-label=".form-select-sm example" wire:model="selectedCity">
                    <option value="-1">Open this select menu</option>
                    <?php $__empty_1 = true; $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($city['name']); ?>"><?php echo e($city['name']); ?></option>    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        
                    <?php endif; ?>
                </select>
            </div>
        <?php endif; ?>

        <?php if($selectedCity): ?>    
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">
                    Pincode
                </label>
                <input type="number" name="pincode" class="form-control form-control-sm" id="exampleFormControlInput1" wire:model="pincode">
                <?php if(session()->has('success')): ?>
                    <span class="text-success">
                        <?php echo e(session('success')); ?>

                    </span>
                <?php endif; ?>
                <?php if(session()->has('error')): ?>
                    <span class="text-danger">
                        <?php echo e(session('error')); ?>

                    </span>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">
                    Delivery Charge
                </label>
                <input type="number" name="deliveryCharge" class="form-control form-control-sm" id="exampleFormControlInput1" wire:model="deliveryCharge">
            </div>

            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">
                    Free Delivery Limit<br><small>(If order total amount exceeds this value delivery charge will be free. Keep empty if above pincode doesn't support free delivery.')</small>
                </label>
                <input type="number" name="freeDeliveryLimit" class="form-control form-control-sm" id="exampleFormControlInput1">
            </div>
        <?php endif; ?>
    </div>
    <?php if($validPincode && $deliveryCharge): ?>    
        <div class="modal-footer">
            <button type="submit" class="btn bluebg btn-sm">Add/Save City</button>
        </div>
    <?php endif; ?>
</form><?php /**PATH C:\Users\adina\Desktop\skyline\resources\views/livewire/admin/pincode-form.blade.php ENDPATH**/ ?>