<div class="tab-pane fade show active" id="cat3" role="tabpanel" aria-labelledby="home-tab">
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Customer Name</th>  
                <th>Trade/Company Name</th>  
                <th>Contact No.</th>
                <th>Ship To</th>
                <th>Status</th>
                <th>Purchased Products</th>

                <th>Purchased Price</th>
                <th>GST No.</th>
                <th>Ordered Date</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>    
                <tr>
                    <td><?php echo e($order->id); ?></td>

                    <td>
                        <div class="tablecellwidth">
                            <p class="mb-0"><?php echo e($order->orderDetail->customerName); ?></p>
                        </div>
                    </td>

                    <td>
                        <div class="tablecellwidth">
                            <p class="mb-0"><?php echo e($order->orderDetail->company); ?></p>
                        </div>
                    </td>

                    <td><?php echo e($order->orderDetail->customerContact); ?></td>

                    <td>
                        <div class="tablecellwidth">
                            <p class="mb-0"><?php echo e($order->orderDetail->houseNumber); ?>, <?php echo e($order->orderDetail->landmark); ?>, <?php echo e($order->orderDetail->area); ?>, <?php echo e($order->orderDetail->town); ?>. <?php echo e($order->orderDetail->pincode); ?></p>
                        </div>
                    </td>

                    <td>
                        <span class="badge bg-success">Delivered</span>
                    </td>

                    <td>
                        <a href="#" data-bs-toggle="modal"
                            data-bs-target="#viewproductsmodal<?php echo e($order->id); ?>">View Products</a>
                    </td>

                    <td>₹<?php echo e($order->orderDetail->payableAmount); ?></td>

                    <td><?php echo e($order->orderDetail->gst); ?></td>

                    <td><?php echo e(date('d M, Y', strtotime($order->created_at))); ?></td>

                </tr>

                <!--modal for view products ordered starts -->
                <div class="modal fade" id="viewproductsmodal<?php echo e($order->id); ?>" tabindex="-1" aria-labelledby="viewproductsmodalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog modal-dialog-scrollable">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">skyline username</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">

                                <div class="d-flex mb-4 justify-content-between align-content-center">
                                    <h6 class="fw-bold">Purchased Products</h6>

                                </div>

                                <?php $__empty_2 = true; $__currentLoopData = $order->orderProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>    
                                    <div class="orderhistoryitem">
                                        <p class="mb-0">
                                            <a href=""><?php echo e($p->product->name); ?></a>
                                        </p>
                                        <p class="mb-0 text-success">₹<?php echo e($p->varient->sellingPrice); ?></p>
                                        <p class="mb-0 text-secondary">Qty: <?php echo e($p->quantity); ?></p>
                                        <p class="mb-0 text-secondary">Varient: <?php echo e($p->varient->name); ?></p>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                    
                                <?php endif; ?>

                                <h6 class="fw-bold">Total Amount: ₹<?php echo e($order->orderDetail->payableAmount); ?></h6>
                            </div>

                        </div>
                    </div>
                </div>
                <!--modal for view products ordered  ends-->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>No delivered orders</p>
            <?php endif; ?>

        </tbody>
    </table>

    <nav aria-label="Page navigation example">
        <ul class="pagination pagination-sm justify-content-end">
            <?php echo e($orders->appends(request()->query())->links('pagination::bootstrap-4')); ?>

        </ul>
    </nav>
</div><?php /**PATH C:\Users\adina\Desktop\skyline\resources\views/components/admin/delivered-orders.blade.php ENDPATH**/ ?>