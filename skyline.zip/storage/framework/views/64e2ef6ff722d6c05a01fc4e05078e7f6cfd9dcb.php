<div class="tab-pane fade show active" id="cat2" role="tabpanel" aria-labelledby="home-tab">
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Customer Name</th>  
                <th>Trade/Company Name</th>  
                <th>Contact No.</th>
                <th>Ship To</th>
                <th>Status</th>
                <th>Purchased Products</th>

                <th>Purchased Price</th>
                <th>GST No.</th>
                <th>Ordered Date</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>    
                <tr>
                    <td><?php echo e($order->id); ?></td>
                    <td>
                        <div class="tablecellwidth">
                            <p class="mb-0"><?php echo e($order->orderDetail->customerName); ?></p>
                        </div>
                    </td>
                    <td>
                        <div class="tablecellwidth">
                            <p class="mb-0"><?php echo e($order->orderDetail->company); ?></p>
                        </div>
                    </td>
                    <td><?php echo e($order->orderDetail->customerContact); ?></td>
                    <td>
                        <div class="tablecellwidth">
                            <p class="mb-0"><?php echo e($order->orderDetail->houseNumber); ?>, <?php echo e($order->orderDetail->landmark); ?>, <?php echo e($order->orderDetail->area); ?>, <?php echo e($order->orderDetail->town); ?>. <?php echo e($order->orderDetail->pincode); ?></p>
                        </div>
                    </td>
                    <td>
                        <div class="d-flex editstatusbtn" data-bs-toggle="modal"
                            data-bs-target="#statusupdate<?php echo e($order->id); ?>">
                            <?php if($order->status == config('constants.orderStatus.accepted')): ?>
                                <span class="badge bg-success">Order Accepted</span>
                            <?php elseif($order->status == config('constants.orderStatus.packed')): ?>
                                <span class="badge bg-secondary">Packed</span>
                            <?php elseif($order->status == config('constants.orderStatus.shipped')): ?>
                                <span class="badge bg-primary">Shipped</span>
                            <?php elseif($order->status == config('constants.orderStatus.outForDelivery')): ?>
                                <span class="badge bluebg">Out For Delivery</span>
                            <?php endif; ?>
                            <span class="material-icons" style="font-size: 21px;">
                                edit_note
                            </span>
                        </div>  

                    </td>
                    <td>
                        <a href="#" data-bs-toggle="modal"
                            data-bs-target="#viewproductsmodal<?php echo e($order->id); ?>">View Products</a>
                    </td>

                    <td>₹<?php echo e($order->orderDetail->payableAmount); ?></td>
                    <td><?php echo e($order->orderDetail->gst); ?></td>
                    <td><?php echo e(date('d M, Y', strtotime($order->created_at))); ?></td>

                </tr>

                <!--modal for status update starts  -->
                <div class="modal fade" id="statusupdate<?php echo e($order->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-sm">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">skyline username</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <form action="<?php echo e(route('admin.orders.update', $order)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>  
                                <div class="modal-body">
                                    <div class="mb-3">
                                        <label for="exampleFormControlInput1" class="form-label fw-bold">Status :</label>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="status" id="flexRadioDefault1" <?php if($order->status == config('constants.orderStatus.accepted')): ?> checked <?php endif; ?> value="<?php echo e(config('constants.orderStatus.accepted')); ?>">
                                            <label class="form-check-label" for="flexRadioDefault1">
                                                Order Accepted
                                            </label>
                                        </div>
        
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="status" id="flexRadioDefault1" <?php if($order->status == config('constants.orderStatus.packed')): ?> checked <?php endif; ?> value="<?php echo e(config('constants.orderStatus.packed')); ?>">
                                            <label class="form-check-label" for="flexRadioDefault1">
                                                Order Packed
                                            </label>
                                        </div>
        
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="status" id="flexRadioDefault2" <?php if($order->status == config('constants.orderStatus.shipped')): ?> checked <?php endif; ?> value="<?php echo e(config('constants.orderStatus.shipped')); ?>">
                                            <label class="form-check-label" for="flexRadioDefault2">
                                                Order Shipped
                                            </label>
                                        </div>
        
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="status" id="flexRadioDefault3" <?php if($order->status == config('constants.orderStatus.outForDelivery')): ?> checked <?php endif; ?> value="<?php echo e(config('constants.orderStatus.outForDelivery')); ?>">
                                            <label class="form-check-label" for="flexRadioDefault3">
                                                Out For Delivery
                                            </label>
                                        </div>
        
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="status" id="flexRadioDefault3" <?php if($order->status == config('constants.orderStatus.delivered')): ?> checked <?php endif; ?> value="<?php echo e(config('constants.orderStatus.delivered')); ?>">
                                            <label class="form-check-label" for="flexRadioDefault3">
                                                Order Delivered
                                            </label>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="mb-3">
                                        <label for="exampleFormControlInput1" class="form-label fw-bold">Estimated Delivery
                                            Date :</label>
        
                                            <input type="date" name="date" class="form-control form-control-sm" value="<?php echo e(date('Y-m-d', strtotime($order->estimatedDate))); ?>">
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn bluebg btn-sm">Update Status</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!--modal for status update ends  -->

                <!--modal for view products ordered starts -->
                <div class="modal fade" id="viewproductsmodal<?php echo e($order->id); ?>" tabindex="-1" aria-labelledby="viewproductsmodalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog modal-dialog-scrollable">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">skyline username</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">

                                <div class="d-flex mb-4 justify-content-between align-content-center">
                                    <h6 class="fw-bold">Purchased Products</h6>

                                </div>

                                <?php $__empty_2 = true; $__currentLoopData = $order->orderProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>    
                                    <div class="orderhistoryitem">
                                        <p class="mb-0">
                                            <a href=""><?php echo e($p->product->name); ?></a>
                                        </p>
                                        <p class="mb-0 text-success">₹<?php echo e($p->varient->sellingPrice); ?></p>
                                        <p class="mb-0 text-secondary">Qty: <?php echo e($p->quantity); ?></p>
                                        <p class="mb-0 text-secondary">Varient: <?php echo e($p->varient->name); ?></p>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                    
                                <?php endif; ?>



                                <h6 class="fw-bold">Total Amount: ₹<?php echo e($order->orderDetail->payableAmount); ?></h6>
                            </div>

                        </div>
                    </div>
                </div>
                <!--modal for view products ordered  ends-->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>No orders in progress</p>
            <?php endif; ?>

        </tbody>
    </table>
    <!-- pagination -->
    <nav aria-label="Page navigation example">
        <ul class="pagination pagination-sm justify-content-end">
            <?php echo e($orders->appends(request()->query())->links('pagination::bootstrap-4')); ?>

        </ul>
    </nav>
</div>
<?php /**PATH C:\Users\adina\Desktop\skyline\resources\views/components/admin/orders-in-progress.blade.php ENDPATH**/ ?>