

<?php $__env->startSection('ogtitle', 'Skyline Distributors | Aurangabad'); ?>
<?php $__env->startSection('title', 'Your Account'); ?>

<?php $__env->startSection('content'); ?>

<!-- breadcrumb start -->
<nav id="breadcrumbproductinfo" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
      <li class="breadcrumb-item active" aria-current="page">Your Account</li>

    </ol>
  </nav>
  <!-- breadcrumb ends -->


  <!-- register form start -->
  <div class="registeruserform youraccountform mt-0 mb-4">
    <h4 class="mb-4 text-center">
      Your Account
    </h4>

    <form action="<?php echo e(route('users.update', $user)); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PATCH'); ?>
      <div class="youraccountformparts">
        <div class="youraccountformpartsdiv">
          <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">User Name<span class="mandatoryfield">*</span>
            </label>
            <input type="text" name="name" class="form-control" id="exampleFormControlInput1" value="<?php echo e($user->name); ?>">
          </div>

          <div class="mb-3">
            <label for="exampleFormControlInput2" class="form-label">Mobile Number 1<span
                class="mandatoryfield">*</span>
            </label>
            <input type="text" name="mobile" class="form-control" id="exampleFormControlInput2" value="<?php echo e($user->mobile); ?>" readonly>
          </div>

          <div class="mb-3">
            <label for="exampleFormControlInput3" class="form-label">Mobile Number 2
            </label>
            <input type="text" name="mobile2" class="form-control" id="exampleFormControlInput3" value="<?php echo e($user->mobile2); ?>">
          </div>

          <div class="mb-4">
            <label for="exampleFormControlInput4" class="form-label">Email Address</label>
            <input type="email" name="email" class="form-control" id="exampleFormControlInput4" value="<?php echo e($user->email); ?>" readonly>
          </div>

          <div class="mt-4">
            <label for="exampleFormControlInput6" class="form-label">GST Information</label>
            <input type="text" name="gst" class="form-control mb-2 mb-lg-3" id="exampleFormControlInput6" placeholder="GST Number" value="<?php echo e($user->gstNumber); ?>">
            <input type="text" name="company" class="form-control mb-2 mb-lg-3" id="exampleFormControlInput6" placeholder="Trade/Company Name" value="<?php echo e($user->company); ?>">
          </div>

        </div>

        <div class="youraccountformpartsdiv">
          <div class="mb-3">
            <label for="exampleFormControlInput6" class="form-label">Address</label>
            <input type="text" name="pincode" class="form-control mb-2" id="exampleFormControlInput4" placeholder="Pincode" value="<?php echo e($address->pincode); ?>">

            <input type="text" name="town" class="form-control mb-2" id="exampleFormControlInput4" placeholder="Town/City" value="<?php echo e($address->town); ?>">

            <input type="text" name="area" class="form-control mb-2" id="exampleFormControlInput4" placeholder="Area, Colony, Street, Sector, Village" name="<?php echo e($address->area); ?>">

            <input type="text" name="houseNumber" class="form-control mb-2" id="exampleFormControlInput4" placeholder="Flat, House no, Building, Company, Apartment" name="<?php echo e($address->houseNumber); ?>">

            <input type="text" name="landmark" class="form-control mb-2 mb-lg-3" id="exampleFormControlInput4" placeholder="Landmark eg. near Max Hospital" name="<?php echo e($address->landmark); ?>">

          </div>

          <div class="mb-3 insightsaccount mt-4">

            <div class="insightbox">
              <div class="count">
                <p class="mb-0">100</p>
              </div>
              <div class="insighttxt">
                <p class="mb-0">Your Orders</p>
              </div>
            </div>

            <div class="insightbox">
              <div class="count">
                <p class="mb-0"><?php echo e(Cart::session(Auth::id())->getTotalQuantity()); ?></p>
              </div>
              <div class="insighttxt">
                <p class="mb-0">Your Cart</p>
              </div>
            </div>

            <div class="insightbox">
              <div class="count">
                <p class="mb-0">2</p>
              </div>
              <div class="insighttxt">
                <p class="mb-0">Quote Requests</p>
              </div>
            </div>

          </div>
        </div>
      </div>

      <div class="registerloginbtn mb-2">
        <button class="btn w-100" type="submit">Update</button>
      </div>

    </form>
  </div>
  <!-- register form ends -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['header' => 'small', 'footer' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adina\Desktop\skyline\resources\views/users/edit.blade.php ENDPATH**/ ?>