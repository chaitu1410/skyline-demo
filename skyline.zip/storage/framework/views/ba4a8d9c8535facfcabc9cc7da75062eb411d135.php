<div class="container-fluid">

    <div class="allcontents bg-white p-2 mt-2">

        <!--add product form-->
        <div class="bg-white mt-2 pt-3 p-lg-3">
                <div class="row">
                    <div class="mb-3">
                        <label class="form-label small">Category :</label>
                        <select class="form-select form-select-sm" aria-label=".form-select-sm example" wire:model="categoryId">
                            <option selected="selected">Open this select menu</option>
                            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                
                            <?php endif; ?>
                        </select>
                    </div>

                    
                </div>

                <div class="mb-4">
                    <label class="form-label small">Product Name :</label>
                    <select class="form-select form-select-sm" aria-label=".form-select-sm example" wire:model="productId" <?php if($productDisabled): ?> disabled <?php endif; ?>>
                        <option selected="selected">Open this select menu</option>
                        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            
                        <?php endif; ?>
                    </select>
                </div>

                <hr>
                <div class="mt-4 mb-3 prodvariants">

                    <?php if($showContent): ?>
                        <div class="mb-3">
                            <label class="form-label small">Add Product Variants :</label>
                            <a class="btn bluebg btn-sm" data-bs-toggle="modal"
                                data-bs-target="#addvariantmodal">Add New Variant</a>
                        </div>
                        <div class="addedvariantcont small">

                            <?php $__empty_1 = true; $__currentLoopData = $varients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $varient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php if($varient->name != 'base'): ?>
                                    <div class="addedvariant">
                                        <div data-bs-toggle="modal" data-bs-target="#editvariantmodal<?php echo e($varient->id); ?>">
                                            
                                            <div class="addedvarprice">
                                                
                                                <p class="mb-1">MRP: ₹<?php echo e($varient->mrp); ?></p>
                                                <p class="mb-1">Discount: <?php echo e($varient->discount); ?>%</p>
                                                <p class="mb-1">GST: <?php echo e($varient->gst); ?>%</p>
                                                <p class="mb-1">Selling Price : <strong>₹<?php echo e($varient->sellingPrice); ?></strong></p>
                                                <?php if($varient->stock): ?>
                                                    <p class="mb-0 text-success"><strong> In Stock</strong></p>
                                                <?php else: ?>
                                                    <p class="mb-0 text-danger"><strong> Out of Stock</strong></p>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <a id="seemorelessbtn" data-bs-toggle="collapse" href="#variantproperties<?php echo e($varient->id); ?>"
                                                aria-expanded="false" aria-controls="collapseExample">
                                                See More
                                        </a>

                                        <div class="collapse" id="variantproperties<?php echo e($varient->id); ?>">
                                            <div class="addedvarprops">
                                                <?php $__empty_2 = true; $__currentLoopData = $varient->properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                    <p class="mb-1"><?php echo e($property->property); ?>: <?php echo e($property->value); ?></p>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                    <p class="mb-1">No properties are added to this varient</p>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div> 
                                    
                                    <!--modal for edit variant starts -->
                                    <div class="modal fade" id="editvariantmodal<?php echo e($varient->id); ?>" tabindex="-1" aria-labelledby="addvariantmodalLabel"
                                        aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-scrollable modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Edit Variant</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                
                                                    <div class="modal-body">
                                                        <form action="<?php echo e(route('admin.products.updateVarient', [ $productId, $varient->id ])); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field("PATCH"); ?>
                                                            <label class="form-label">Variant Name 1:</label>
                                                            <div class="prodvariantvalues mb-3">
                                                                <div class="valuepriceip valuepriceip2">
                                                                    <input type="text" class="form-control form-control-sm" name="name" value="<?php echo e($varient->name); ?>">
                                                                </div>


                                                            </div>
                                                            <div class="prodvariantvalues mb-3">

                                                                <div class="valuepriceip">
                                                                    <input type="text" class="form-control form-control-sm" placeholder="MRP" value="<?php echo e($varient->mrp); ?>" name="mrp">
                                                                </div>

                                                                <div class="valuepriceip">
                                                                    <input type="text" class="form-control form-control-sm" placeholder="Discount" value="<?php echo e($varient->discount); ?>" name="discount">
                                                                </div>

                                                                <div class="valuepriceip">
                                                                    <input type="text" class="form-control form-control-sm" placeholder="GST" value="<?php echo e($varient->gst); ?>" name="gst">
                                                                </div>

                                                                <div class="valuepriceip">
                                                                    <input type="text" class="form-control form-control-sm" placeholder="Selling Price" value="<?php echo e($varient->sellingPrice); ?>" name="sellingPrice">
                                                                </div>
                                                                <div class="valuepriceip">
                                                                    <select class="form-select form-select-sm" aria-label=".form-select-sm example" name="stock">
                                                                        <option value="1" <?php if($varient->stock): ?> selected <?php endif; ?>>In Stock</option>
                                                                        <option value="0" <?php if(!$varient->stock): ?> selected <?php endif; ?>>Out Of Stock</option>
                                                                    </select>
                                                                </div>
                                                            </div>



                                                            <hr>

                                                            <div class="mb-4 mt-3">
                                                                <label class="form-label">Properties :</label>
                                                                <div class="field_wrapperpn">
                                                                    <?php $__empty_2 = true; $__currentLoopData = $varient->properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                                        <div class="mb-3">
                                                                            <input type="text" class="form-control form-control-sm d-inline m-1" placeholder="Property Name" value="<?php echo e($property->property); ?>"
                                                                            name="properties[]" readonly>
                                                        
                                                                            <input type="text" class="form-control form-control-sm d-inline m-1" placeholder="Property Value" value="<?php echo e($property->value); ?>"
                                                                            name="values[]">
                                                                        </div>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                                        <p class="mb-1">No properties are added to this varient</p>
                                                                    <?php endif; ?>
                                                                    
                                                                </div>
                                                            </div>

                                                            <div class="prodsubmitbtn">
                                                                <button class="btn btn-sm btn-danger" type="button" wire:click="deleteVarient(<?php echo e($varient->id); ?>)">Delete Variant</button>
                                                                <button class="btn btn-sm orangebg" type="submit">Update Variant</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>      
                                <p class="mb-1">Varients not available</p>
                            <?php endif; ?>
                        </div>
                        <div class="modal fade" id="addvariantmodal" tabindex="-1" aria-labelledby="addvariantmodalLabel"
                            aria-hidden="true">
                            <div class="modal-dialog modal-dialog-scrollable modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Add New Variant</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <form action="<?php echo e(route('admin.products.storeVarient', $productId)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="modal-body">

                                            <label class="form-label">Add Variant :</label>

                                            <div class="field_wrapper1">
                                                <div class="mb-2">
                                                    <div class="mb-1">
                                                        <input type="text" class="form-control form-control-sm m-1" placeholder="Variant Name"
                                                            name="name">

                                                    </div>

                                                    <div class="d-flex variantmorevalues">
                                                        <input type="text" class="form-control form-control-sm m-1" placeholder="MRP"
                                                            name="mrp" id="mrp" onchange="calculate()">
                                                        <input type="text" class="form-control form-control-sm m-1" placeholder="Discount"
                                                            name="discount" id="discount" onchange="calculate()">
                                                        <input type="text" class="form-control form-control-sm m-1" placeholder="GST"
                                                            name="gst" id="gst" onchange="calculate()"> 
                                                        <input type="text" class="form-control form-control-sm m-1" placeholder="Price"
                                                            name="sellingPrice" id="sellingPrice" readonly>
                                                        <select class="form-select form-select-sm m-1" aria-label=".form-select-sm example"
                                                            name="stock">
                                                            <option selected value="1">In Stock</option>
                                                            <option value="0">Out Of Stock</option>
                                                        </select>
                                                    </div>

                                                    <?php $__empty_1 = true; $__currentLoopData = $baseProperties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                        <div class="prodvariants mt-2 d-flex">

                                                            <input type="text" class="form-control form-control-sm w-50 d-inline m-1"
                                                                placeholder="Property Name" readonly name="properties[]" value="<?php echo e($property->property); ?>">

                                                            <input type="text" class="form-control form-control-sm w-50 d-inline m-1"
                                                                placeholder="Property Value" name="values[]">

                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                        
                                                    <?php endif; ?>

                                                </div>
                                            </div>

                                            <div class="prodsubmitbtn mt-4">
                                                <button type="submit" class="btn btn-sm orangebg">Save/Add Variant</button>
                                            </div>
                                        </div>
                                    </form>

                                </div>
                            </div>
                        </div>
                        <!--modal for add variant ends-->
                </div>
                <?php endif; ?>
        </div>
    </div>
    <?php $__env->startPush('scripts'); ?>
        <script>
            function calculate(){
                var mrp = document.getElementById("mrp").value;
                var gst = document.getElementById("gst").value;
                var discount = document.getElementById("discount").value;
                var sellingPrice = document.getElementById("sellingPrice");

                if(mrp && gst && discount){
                mrp = Number.parseFloat(mrp);
                gst = Number.parseFloat(gst);
                discount = Number.parseFloat(discount);
                var gstAmount = (gst * mrp) / 100;
                var discountAmount = (discount * mrp) / 100;
                sellingPrice.value = (mrp + gstAmount) - discountAmount;
                }
            }   
        </script>
    <?php $__env->stopPush(); ?>
</div>
<?php /**PATH C:\Users\adina\Desktop\skyline\resources\views/livewire/admin/add-varient.blade.php ENDPATH**/ ?>