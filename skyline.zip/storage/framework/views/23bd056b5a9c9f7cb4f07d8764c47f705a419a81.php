<form action="<?php echo e(route('register.post')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="exampleFormControlInput2" class="form-label">Mobile Number
        </label>
        <div id="inputforgetotp">
            <div class="inputforgetotpip">
                <input type="text" class="form-control" id="exampleFormControlInput2" name="mobile" wire:model="mobile" value="<?php echo e(old('mobile')); ?>">
            </div>
           <div class="inputforgetotpbtn">
            <button id="getotpbtn" class="btn btn-success" wire:click.prevent="getOTP">Get OTP</button>
           </div>
        </div>
        <?php if(session()->has('sent')): ?>
            <span class="text-success">
                <?php echo e(session('sent')); ?>

            </span>
        <?php endif; ?>
        <?php if(session()->has('taken')): ?>
            <span class="text-danger">
                <?php echo e(session('taken')); ?>

            </span>
        <?php endif; ?>
    </div>

    <div class="mb-3">
        <label for="exampleFormControlInput2" class="form-label">Verify OTP
        </label>
        <div id="inputforgetotp">
            <div class="inputforgetotpip">
                <input type="text" class="form-control" id="exampleFormControlInput2" name="otp" wire:model="otp">
            </div>
           <div class="inputforgetotpbtn">
            <button id="getotpbtn" class="btn btn-success"  wire:click.prevent="verifyOTP">Verify</button>
           </div>
        </div>
        <?php if(session()->has('correctOTP')): ?>
            <span class="text-success">
                <?php echo e(session('correctOTP')); ?>

            </span>
        <?php endif; ?>
        <?php if(session()->has('incorrectOTP')): ?>
            <span class="text-danger">
                <?php echo e(session('incorrectOTP')); ?>

            </span>
        <?php endif; ?>
    </div>
    
    <?php if($verified): ?>
        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Full Name<span class="mandatoryfield">*</span>
            </label>
            <input type="text" class="form-control" id="exampleFormControlInput1" name="name" value="<?php echo e(old('name')); ?>">
        </div>

        <div class="mb-3">
            <label for="exampleFormControlInput3" class="form-label">Email Address</label>
            <input type="email" class="form-control" id="exampleFormControlInput3" name="email" value="<?php echo e(old('email')); ?>">
        </div>

        <div class="mb-3">
            <label for="exampleFormControlInput4" class="form-label">Create Password<span
                    class="mandatoryfield">*</span>
            </label>
            <input type="password" class="form-control" id="exampleFormControlInput4" name="password">
        </div>

        <div class="mb-3">
            <label for="exampleFormControlInput5" class="form-label">Confirm Password<span
                    class="mandatoryfield">*</span>
            </label>
            <input type="password" class="form-control" id="exampleFormControlInput5" name="password_confirmation">
        </div>

        <div class="registerloginbtn mb-2">
            <button class="btn w-100">Register</button>
        </div>
    <?php endif; ?>

    <div class="signupinlink">
        <a href="<?php echo e(route('login')); ?>">Already Have Account? Click To Sign In</a>
    </div>

    <div>
        <span class="text-secondary small">
            By continuing, you agree to Skyline's Terms and Conditions and the

            <a id="privacypolicylink" data-bs-toggle="modal" data-bs-target="#exampleModal">Privacy Policy</a>.
        </span>
    </div>

</form>
<?php /**PATH C:\Users\adina\Desktop\skyline\resources\views/livewire/register-user.blade.php ENDPATH**/ ?>