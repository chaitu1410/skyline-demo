

<?php $__env->startSection('content'); ?>
<!-- Page content-->
<div class="container-fluid">
    <div class="allcontents bg-white p-2 mt-2">

        <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb breadcrumblinks">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.categories.index')); ?>">Categories</a></li>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e($category->name); ?></li>
            </ol>
        </nav>

        <div class="dataaddactions">
            <div class="addcategorybtns">
                <button class="btn bluebg btn-sm" data-bs-toggle="modal"
                    data-bs-target="#addsubcategorymodal">+ Add Sub-Category</button>

                <button class="btn bluebg btn-sm" onclick="location.href='<?php echo e(route('admin.products.create', $category->id)); ?>'">+ Add
                    Product</button>
            </div>
            
        </div>

        <!-- table -->
        <div id="alldatatable" class="bg-white mt-5 pt-3">
            <div id="catvisetabs">
                <ul class="nav nav-tabs" id="tabcategory" role="tablist">
                    <li class="nav-item" role="presentation">
                        <a class="nav-link <?php if(!($subcategory)): ?> active <?php endif; ?> categorytabhead"
                            role="tab" aria-controls="cat1"
                            aria-selected="true" href="<?php echo e(route('admin.categories.show', ['category' => $category->id])); ?>">All Products</a>
                    </li>
                    <?php $__empty_1 = true; $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="nav-item" role="presentation">
                            <a class="nav-link <?php if($sub == $subcategory): ?> active <?php endif; ?> categorytabhead"
                                role="tab" aria-controls="cat1"
                                aria-selected="true" href="<?php echo e(route('admin.categories.showSubcategory', ['category' => $category->id ,'subcategory' => $sub->id ])); ?>"><?php echo e($sub->name); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        No subcategories available in this category...
                    <?php endif; ?>

                </ul>
            </div>

            <div class="tab-content" id="proTabContent">

                <div class="tab-pane fade show active" id="cat1" role="tabpanel" aria-labelledby="home-tab">
                    <?php if($subcategory): ?>
                        <div class="editsubcategorybtns d-flex">
                            <div class="editsubcatpart">
                                <button class="btn btn-sm btn-secondary" data-bs-toggle="modal"
                                    data-bs-target="#editsubcategorymodal">Edit Subcategory</button>
                            </div>
                            <div class="editsubcatpart">
                                <button class="btn btn-sm btn-danger" data-bs-toggle="modal"
                                    data-bs-target="#deletesubcategorymodal">Delete Subcategory</button>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="productscategorytabcont">
                        <?php if($subcategory): ?>
                            <?php $__empty_1 = true; $__currentLoopData = $subcategory->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="procard card">
                                    <div class="prod-img" onclick="location.href=''">
                                        <img src="<?php echo e(asset('images/'.$product->image)); ?>" class="" alt="...">
                                    </div>

                                    <div class="productdetails" onclick="location.href=''">
                                        <a>
                                            <p class="prodname"><?php echo e($product->name); ?></p>
                                        </a>
                                        <p class="mb-0 text-success prodprice"><span
                                                class="cutprice text-danger"><?php echo e($product->mrp); ?> </span> <?php echo e($product->sellingPrice); ?>

                                        </p>
                                    </div>
                                    <div class="productactions">
                                        <div class="prodaction">
                                            <span id="prodview" class="material-icons text-dark">
                                                visibility
                                            </span>
                                        </div>

                                        <div class="prodaction" onclick="location.href='<?php echo e(route('admin.products.edit', $product->id)); ?>'">
                                            <span id="prodedit" class="material-icons text-dark">
                                                edit
                                            </span>
                                        </div>

                                        <div class="prodaction">
                                            <span id="proddelete" class="material-icons text-danger"
                                                data-bs-toggle="modal" data-bs-target="#deleteproductmodal<?php echo e($product->id); ?>">
                                                delete
                                            </span>
                                        </div>
                                    </div>
                                </div>

                                <!--modal for delete product starts -->
                                <div class="modal fade" id="deleteproductmodal<?php echo e($product->id); ?>" tabindex="-1" aria-labelledby="deleteproductLabel"
                                aria-hidden="true">
                                    <div class="modal-dialog modal-sm">
                                        <form action="<?php echo e(route('admin.products.destroy', $product)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Product Delete</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">

                                                    <div class="mb-3">
                                                        <p>Are you sure that you want to delete this product?</p>
                                                    </div>

                                                </div>
                                                <div class="modal-footer">
                                                    <button type="submit" class="btn btn-danger btn-sm">Confirm Delete</button>
                                                </div>

                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <!--modal for delete product ends-->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                No products available in this subcategory...
                            <?php endif; ?>
                        <?php else: ?>
                            <?php $__empty_1 = true; $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="procard card">
                                <div class="prod-img" onclick="location.href=''">
                                    <img src="<?php echo e(asset('images/'.$product->image)); ?>" class="" alt="...">
                                </div>

                                <div class="productdetails" onclick="location.href=''">
                                    <a>
                                        <p class="prodname"><?php echo e($product->name); ?></p>
                                    </a>
                                    <p class="mb-0 text-success prodprice"><span
                                            class="cutprice text-danger"><?php echo e($product->mrp); ?> </span> <?php echo e($product->sellingPrice); ?>

                                    </p>
                                </div>
                                <div class="productactions">
                                    <div class="prodaction">
                                        <span id="prodview" class="material-icons text-dark">
                                            visibility
                                        </span>
                                    </div>

                                    <div class="prodaction" onclick="location.href='<?php echo e(route('admin.products.edit', $product->id)); ?>'">
                                        <span id="prodedit" class="material-icons text-dark">
                                            edit
                                        </span>
                                    </div>

                                    <div class="prodaction">
                                        <span id="proddelete" class="material-icons text-danger"
                                            data-bs-toggle="modal" data-bs-target="#deleteproductmodal<?php echo e($product->id); ?>">
                                            delete
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <!--modal for delete product starts -->
                            <div class="modal fade" id="deleteproductmodal<?php echo e($product->id); ?>" tabindex="-1" aria-labelledby="deleteproductLabel"
                            aria-hidden="true">
                                <div class="modal-dialog modal-sm">
                                        <form action="<?php echo e(route('admin.products.destroy', $product)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Product Delete</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">

                                                    <div class="mb-3">
                                                        <p>Are you sure that you want to delete this product?</p>
                                                    </div>

                                                </div>
                                                <div class="modal-footer">
                                                    <button type="submit" class="btn btn-danger btn-sm">Confirm Delete</button>
                                                </div>

                                            </div>
                                        </form>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                
                            <?php endif; ?>

                        <?php endif; ?>
                        
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>

<!-- add sub category modal starts -->
<div class="modal fade" id="addsubcategorymodal" tabindex="-1" aria-labelledby="addcategorymodalLabel"
aria-hidden="true">
    <div class="modal-dialog">
        <form action="<?php echo e(route('admin.subcategories.store', $category->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Sub-Category</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="field_wrapper">
                        <div class="d-flex mb-3">
                            <input type="text" class="form-control form-control-sm" placeholder="Add Subcategory "
                                name="subcategory">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn bluebg btn-sm">Add/Save Sub-Category</button>
                </div>
            </div>
        </form>
    </div>
</div>
<!-- add category modal ends -->

<?php if($subcategory): ?>
    <!-- edit sub category modal starts -->
    <div class="modal fade" id="editsubcategorymodal" tabindex="-1" aria-labelledby="editcategorymodalLabel"
    aria-hidden="true">
        <div class="modal-dialog">
            <form action="<?php echo e(route('admin.subcategories.update', $subcategory)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Edit Sub-Category</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
            
                        <div class="d-flex mb-3">
                            <input type="text" class="form-control form-control-sm" placeholder="Add Subcategory "
                                name="subcategory" value="<?php echo e($subcategory->name); ?>">
                        </div>
            
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn bluebg btn-sm">Update Sub-Category</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <!-- edit category modal ends -->

    <!-- delete confirm modal starts -->
    <div class="modal fade" id="deletesubcategorymodal" tabindex="-1" aria-labelledby="deletecategorymodalLabel"
    aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <form action="<?php echo e(route('admin.subcategories.destroy', ['category' => $category, 'subcategory' => $subcategory])); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Delete Sub-Category</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">

                        <div class="mb-3">
                            <p class="mb-2">Are you sure that you want to delete this subcategory ?</p>
                            <p class="mb-0">
                                <small class="text-danger">Note: All the products in this subcategory will be
                                    deleted.</small>
                            </p>

                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-danger btn-sm">Confirm Delete</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <!-- delete confirm modal ends -->
<?php endif; ?>




<!-- Page content ends-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adina\Desktop\skyline\resources\views/admin/categories/show.blade.php ENDPATH**/ ?>