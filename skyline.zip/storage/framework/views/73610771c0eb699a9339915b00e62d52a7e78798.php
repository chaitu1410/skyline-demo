<div class="tab-pane fade show active" id="cat1" role="tabpanel" aria-labelledby="home-tab">
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Customer Name</th>
                <th>Trade/Company Name</th>
                <th>Contact No.</th>
                <th>Ship To</th>
                <th>Purchased Products</th>
                <th>Purchased Price</th>
                <th>GST No.</th>
                <th>Ordered Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>    
                <tr>
                    <td><?php echo e($order->id); ?></td>
                    <td>
                        <div class="tablecellwidth">
                            <p class="mb-0"><?php echo e($order->orderDetail->customerName); ?></p>
                        </div>
                    </td>
                    <td>
                        <div class="tablecellwidth">
                            <p class="mb-0"><?php echo e($order->orderDetail->company); ?></p>
                        </div>
                    </td>
                    <td><?php echo e($order->orderDetail->customerContact); ?></td>
                    <td>
                        <div class="tablecellwidth">
                            <p class="mb-0"><?php echo e($order->orderDetail->houseNumber); ?>, <?php echo e($order->orderDetail->landmark); ?>, <?php echo e($order->orderDetail->area); ?>, <?php echo e($order->orderDetail->town); ?>. <?php echo e($order->orderDetail->pincode); ?></p>
                        </div>
                    </td>
                    <td>
                        <a href="#" data-bs-toggle="modal"
                            data-bs-target="#viewproductsmodal<?php echo e($order->id); ?>">View Products</a>
                    </td>

                    <td>₹<?php echo e($order->orderDetail->payableAmount); ?></td>
                    <td><?php echo e($order->orderDetail->gst); ?></td>
                    <td><?php echo e(date('d M, Y', strtotime($order->created_at))); ?></td>

                    <td>
                        <div class="d-flex">
                            <button class="btn bg-success btn-sm" data-bs-toggle="modal"
                                data-bs-target="#acceptordermodal<?php echo e($order->id); ?>">
                                <span class="material-icons text-white">
                                    done
                                </span>
                            </button>

                            <button class="btn btn-danger btn-sm" data-bs-toggle="modal"
                                data-bs-target="#rejectordermodal">
                                <span class="material-icons">
                                    close
                                </span>
                            </button>
                        </div>

                    </td>
                </tr>
                <!--modal for order confirm starts -->
                <div class="modal fade" id="acceptordermodal<?php echo e($order->id); ?>" tabindex="-1" aria-labelledby="viewusermodalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-sm">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">skyline username</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <form action="<?php echo e(route('admin.orders.confirm', $order)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <div class="modal-body">
                                    <div class="mb-3">
                                        <label for="exampleFormControlInput1" class="form-label fw-bold">Estimated Delivery
                                            Date :</label>
                                        <input type="date" name="date" class="form-control form-control-sm" value="<?php echo e(date('Y-m-d', strtotime($order->estimatedDate))); ?>">
                                    </div>
    
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn bluebg btn-sm">Update</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!--modal for order confirm ends-->

                   <!--modal for reject confirm starts -->
                    <div class="modal fade" id="rejectordermodal" tabindex="-1" aria-labelledby="viewusermodalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-sm">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">skyline username</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <form action="<?php echo e(route('admin.orders.cancel', $order)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <div class="modal-body">
                                        <div class="mb-3">
                                            <p>Are you sure that you want to reject this order ?</p>
                                        </div>
                                        <textarea class="form-control form-control-sm" name="reason" id="exampleFormControlTextarea1" rows="5"
                                            placeholder="Write reason to reject order..."></textarea>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-danger btn-sm">Confirm Reject Order</button>
                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                    <!--modal for reject confirm ends-->

                <!--modal for view products ordered starts -->
                <div class="modal fade" id="viewproductsmodal<?php echo e($order->id); ?>" tabindex="-1" aria-labelledby="viewproductsmodalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-dialog-scrollable">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">skyline username</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">

                            <div class="d-flex mb-4 justify-content-between align-content-center">
                                <h6 class="fw-bold">Purchased Products</h6>

                            </div>

                            <?php $__empty_2 = true; $__currentLoopData = $order->orderProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>    
                                <div class="orderhistoryitem">
                                    <p class="mb-0">
                                        <a href=""><?php echo e($p->product->name); ?></a>
                                    </p>
                                    <p class="mb-0 text-success">₹<?php echo e($p->varient->sellingPrice); ?></p>
                                    <p class="mb-0 text-secondary">Qty: <?php echo e($p->quantity); ?></p>
                                    <p class="mb-0 text-secondary">Varient: <?php echo e($p->varient->name); ?></p>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                
                            <?php endif; ?>



                            <h6 class="fw-bold">Total Amount: ₹<?php echo e($order->orderDetail->payableAmount); ?></h6>
                        </div>

                    </div>
                </div>
            </div>
            <!--modal for view products ordered  ends-->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>No new orders</p>
            <?php endif; ?>


        </tbody>
    </table>
    <!-- pagination -->
    <nav aria-label="Page navigation example">
        <ul class="pagination pagination-sm justify-content-end">
            <?php echo e($orders->appends(request()->query())->links('pagination::bootstrap-4')); ?>

        </ul>
    </nav>
</div><?php /**PATH C:\Users\adina\Desktop\skyline\resources\views/components/admin/new-orders.blade.php ENDPATH**/ ?>