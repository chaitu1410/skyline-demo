<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <title>Skyline | Admin</title>
  <?php echo \Livewire\Livewire::styles(); ?>


  <!-- Favicons -->
  <link href="<?php echo e(asset('assets/admin/images/favicon.png')); ?>" rel="icon">
  <link href="<?php echo e(asset('assets/admin/images/favicon.png')); ?>" rel="apple-touch-icon">
  <!-- material icons -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <!-- Core theme CSS (includes Bootstrap)-->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <link href="<?php echo e(asset('assets/admin/css/styles.css')); ?>" rel="stylesheet" />

  <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"
    integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4=" crossorigin="anonymous"></script>
    <!-- Bootstrap core JS-->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
  <script type="text/javascript" src="<?php echo e(asset('assets/admin/js/image-uploader.min.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('assets/admin/js/properties-dynamicfields.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('assets/admin/js/properties-subcategory.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('assets/admin/js/properties-variants.js')); ?>"></script>


  <meta name="author" content="Kunal Pandharkar">
  <meta name="twitter:title" content="Skyline | Admin">
  <meta name="twitter:description"
    content="designed and promoted by maharashtra industries directory, www.maharashtradirectory.com" />
  <meta property="og:title" content="Skyline | Admin">
  <meta property="og:url" content="wwww.skyline.com">
  <meta property="og:image" content="https://samvaidya961.github.io/skylineadmin/assets/images/favicon.png">
  <meta property="og:image:type" content="image/png">
  <meta property="og:image:width" content="1024">
  <meta property="og:image:height" content="1024">
  <!-- texteditor js cdn -->
  <script src="https://cdn.ckeditor.com/ckeditor5/29.1.0/classic/ckeditor.js"></script>
  <!-- image uploader css -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/image-uploader.min.css')); ?>">

</head>

<body>


  <div class="d-flex" id="wrapper">
    
    <?php if (isset($component)) { $__componentOriginalf876cca3a28f659cd5d542fa68eb46dbaafc0d1d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\Sidebar::class, []); ?>
<?php $component->withName('admin.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf876cca3a28f659cd5d542fa68eb46dbaafc0d1d)): ?>
<?php $component = $__componentOriginalf876cca3a28f659cd5d542fa68eb46dbaafc0d1d; ?>
<?php unset($__componentOriginalf876cca3a28f659cd5d542fa68eb46dbaafc0d1d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>


    <!-- Page content wrapper-->
    <div id="page-content-wrapper">
    
      <?php if (isset($component)) { $__componentOriginal2a47292f4e4050071cfddfd6ba8e2a3a4c127757 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\Header::class, []); ?>
<?php $component->withName('admin.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal2a47292f4e4050071cfddfd6ba8e2a3a4c127757)): ?>
<?php $component = $__componentOriginal2a47292f4e4050071cfddfd6ba8e2a3a4c127757; ?>
<?php unset($__componentOriginal2a47292f4e4050071cfddfd6ba8e2a3a4c127757); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

      <?php if($message = Session::get('success')): ?>
        <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, []); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?><?php echo e($message); ?> <?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
      <?php elseif($message = Session::get('error')): ?>
        <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Alert::class, ['type' => 'danger']); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?><?php echo e($message); ?> <?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
      <?php endif; ?>

      <!-- Page content-->
      <?php echo $__env->yieldContent('content'); ?>
      <!-- Page content ends-->

    </div>
  </div>
  
  <?php echo $__env->yieldPushContent('scripts'); ?>
  <!-- Core theme JS-->
  <script src="<?php echo e(asset('assets/admin/js/scripts.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/admin/js/calendar.js')); ?>"></script>
  <?php echo \Livewire\Livewire::scripts(); ?>

</body>

</html><?php /**PATH C:\Users\adina\Desktop\skyline\resources\views/admin/layouts/main.blade.php ENDPATH**/ ?>