<div>
    <?php if(Cart::session(Auth::id())->getTotalQuantity() > 0): ?>
    <section>
        <!-- shopping cart start -->
    
        <div id="yourcartheading">
          <div class="siteheading">
            <h6>
              Shopping Cart
            </h6>
          </div>
          <div class="headingunderline"></div>
          <a id="deselectallitems" href="#" wire:click.prevent="clearAllCart">
            <p class="mb-0">Delete All Items</p>
          </a>
        </div>
    
        <div class="yourcartcontainers">
          <div id="yourcartsubtotal">
    
            <div class="purchaseprotectcont">
              <div class="purchaseprotectimg">
                <img src="assets/images/skyline-protect.png" alt="">
              </div>
              <div class="purchaseprotecttxt">
                <p class="mb-0">100% Purchase Protection</p>
                <p class="mb-0 text-danger">Original Products | Secure Payments</p>
              </div>
            </div>
    
            <div class="yourcartsubtotalhead">
              <p>Subtotal (<?php echo e(Cart::session(Auth::id())->getTotalQuantity()); ?> Items )
                <strong>₹<?php echo e(Cart::session(Auth::id())->getTotal()); ?></strong>
              </p>
            </div>
            <p class="text-success small">Your order is eligible for FREE Delivery.</p>
            
              
              <a href="<?php echo e(route('orders.confirm')); ?>" class="btn bg-orange w-100">Proceed To Buy</a>
            
          </div>
    
          <div id="yourcartitems">
              <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                <div class="yourcartitem">
                    <div class="yourcartitemimg">
                    <img src="<?php echo e(asset('images/'.$item['associatedModel']['image'])); ?>" alt="">
                    </div>
                    <div class="yourcartitemdetails">
                    <div class="prodinfoname" onclick="location.href='<?php echo e(route('products.show', $item['associatedModel']['slug'])); ?>'">
                        <p><?php echo e($item['name']); ?> <br> <span><small>Varient: <?php echo e($item['attributes']['varient']['name']); ?></small></span> </p>
                    </div>
                    
                    <?php if($item['associatedModel']['verified']): ?>
                        <div id="verifiedbadge" class="mb-2">
                            <p class="mb-0">Skyline <span id="verifiedtxt">Verified</span><span class="material-icons">
                                verified_user
                            </span> </p>
                        </div>
                    <?php endif; ?>
        
        
                    <div class="prodpricees">
                        <p class="mb-1">Price: <span class="text-success"><strong> ₹<?php echo e($item['attributes']['varient']['sellingPrice']); ?></strong></span></p>
                        <p class="mb-1">FREE Delivery: <strong class="text-dark"><?php echo e(date('M d', strtotime(\Carbon::now()->addDays(15)))); ?> - <?php echo e(date('M d', strtotime(Carbon::now()->addDays(20)))); ?></strong></p>
                    </div>
        
        
                    <div class="prodmoredetails">
                        <?php if($item['associatedModel']['stock']): ?>
                            <p class="mb-2 text-success small">In Stock.</p>
                        <?php else: ?>
                            <p class="mb-2 text-danger small">Out Of Stock.</p>
                        <?php endif; ?>
                    </div>
        
                    <div class="quantityincdec quantityincdecyourcart">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('cart-update', ['item' => $item])->html();
} elseif ($_instance->childHasBeenRendered($item['id'])) {
    $componentId = $_instance->getRenderedChildComponentId($item['id']);
    $componentTag = $_instance->getRenderedChildComponentTagName($item['id']);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($item['id']);
} else {
    $response = \Livewire\Livewire::mount('cart-update', ['item' => $item]);
    $html = $response->html();
    $_instance->logRenderedChild($item['id'], $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        <a class="deleteitemcartlink" href="#" wire:click.prevent="removeCart('<?php echo e($item['id']); ?>')">Delete</a>
                    </div>
                    </div>
                </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <!-- shopping cart end -->
      </section>
      <?php else: ?>
        <h2>No items in the cart</h2>
      <?php endif; ?>
</div>
<?php /**PATH C:\Users\adina\Desktop\skyline\resources\views/livewire/cart-list.blade.php ENDPATH**/ ?>