<div>
    <!-- table -->
<div id="alldatatable" class="bg-white mt-2 pt-3">
    <div id="allcategories">

        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="categoryitemcont">
                <div class="categoryitem" onclick="location.href='category.html'">
                    <div class="categoryimg">
                        <img src="<?php echo e(asset('images/'.$category->image)); ?>" alt="">
                    </div>

                    <div class="categoryname">
                        <p class="mb-1"><?php echo e($category->name); ?></p>
                    </div>
                </div>
                <div class="categoryactions">
                    <div class="categoryaction" onclick="location.href='category.html'">
                        <span class="material-icons text-dark">
                            visibility
                        </span>
                    </div>
                    <button class="categoryaction" wire:click="onEditClick(<?php echo e($category->id); ?>)">
                        <span class="material-icons text-dark">
                            edit
                        </span>
                    </button>

                    <div class="categoryaction" data-bs-toggle="modal"
                        data-bs-target="#deletecategorymodal">
                        <span class="material-icons text-danger">
                            delete
                        </span>
                    </div>
                </div>
            </div>

            
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            Categories not available...
        <?php endif; ?>

        <!-- edit category modal starts -->
        <div class="modal fade modal" id="" tabindex="-1" aria-labelledby="editcategorymodalLabel"
            <?php if($showModal): ?> aria-hidden="true" <?php endif; ?> >
                <?php if (isset($component)) { $__componentOriginal0cf1214cafaa66080a60e11c6925fa1970f28ddf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\EditCategory::class, []); ?>
<?php $component->withName('admin.edit-category'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal0cf1214cafaa66080a60e11c6925fa1970f28ddf)): ?>
<?php $component = $__componentOriginal0cf1214cafaa66080a60e11c6925fa1970f28ddf; ?>
<?php unset($__componentOriginal0cf1214cafaa66080a60e11c6925fa1970f28ddf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>

    </div>

</div>

<!-- pagination -->
<nav aria-label="Page navigation example">
    <ul class="pagination pagination-sm justify-content-end">
        <li class="page-item">
            <a class="page-link" href="#" aria-label="Previous">
                <span aria-hidden="true">&laquo;</span>
            </a>
        </li>
        <li class="page-item active" aria-current="page">
            <span class="page-link">1</span>
        </li>
        <li class="page-item"><a class="page-link" href="#">2</a></li>
        <li class="page-item"><a class="page-link" href="#">3</a></li>
        <li class="page-item">
            <a class="page-link" href="#" aria-label="Next">
                <span aria-hidden="true">&raquo;</span>
            </a>
        </li>
    </ul>
</nav>
</div>
<?php /**PATH C:\Users\adina\Desktop\skyline\resources\views/livewire/admin/categories-list.blade.php ENDPATH**/ ?>