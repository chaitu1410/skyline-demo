<div id="toastmsg" class="alert alert-<?php echo e($type); ?> alert-dismissible" role="alert">
    <p class="mb-0"><?php echo e($slot); ?></p>
    <button type="button" class="btn btn-sm" data-bs-dismiss="alert" aria-label="Close">
        <span class="material-icons">
            close
        </span>
    </button>
</div><?php /**PATH C:\Users\adina\Desktop\skyline\resources\views/components/alert.blade.php ENDPATH**/ ?>