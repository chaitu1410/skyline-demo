

<?php $__env->startSection('ogtitle', 'Skyline Distributors | Aurangabad'); ?>
<?php $__env->startSection('title', 'Your Orders'); ?>

<?php $__env->startSection('content'); ?>

    <!-- breadcrumb start -->
    <nav id="breadcrumbproductinfo" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Your Returns</li>
        </ol>
    </nav>
    <!-- breadcrumb ends -->

    <style>
        .seemorereply {
            color: var(--blue);
            font-size: 13px;
            margin-left: 1rem;
            text-decoration: underline var(--blue);
        }

        .seemorereply:hover {
            color: var(--blue);
            text-decoration: underline var(--blue);
        }
    </style>
    <section>
        <!-- your orders start -->

        <div id="yourcartheading">
            <div class="siteheading">
                <h6>
                    Your Cancelled Orders
                </h6>
            </div>
            <div class="headingunderline"></div>
        </div>

        <div id="assistanthelpsection">
            <div class="assistanthelpitem">
                <div>
                    <img id="assistanthelpimg" src="<?php echo e(asset('assets/images/assistant.png')); ?>" alt="">
                </div>
                <div>
                    <button class="btn bluebg">Request Bulk Quote Now</button>

                </div>
            </div>
            <div class="assistanthelpitem">
                <img src="<?php echo e(asset('assets/images/approved.png')); ?>" alt="">
            </div>
        </div>


        <div id="yourorderscont">

            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="yourordersitem">
                    <div class="yourordersitemheader">
                        <div class="yourordersitemheaderitem">
                            <p class="mb-0 fw-bold">ORDER PLACED</p>
                            <p class="mb-0 fw-bold"><?php echo e(date('d M, Y', strtotime($order->created_at))); ?></p>
                        </div>

                        <div class="yourordersitemheaderitem">
                            <p class="mb-0">TOTAL</p>
                            <p class="mb-0">₹<?php echo e($order->orderDetail->payableAmount); ?></p>
                        </div>

                        <div class="yourordersitemheaderitem">
                            <p class="mb-0">SHIP TO</p>
                            <p class="mb-0 text-primary"><?php echo e($order->orderDetail->customerName); ?></p>
                        </div>

                        <div class="yourordersitemheaderitem">
                            <p class="mb-0">ORDER ID</p>
                            <p class="mb-0"># <?php echo e($order->id); ?></p>
                        </div>

                    </div>
                    <div class="p-3">
                        <div>
                            <p class="yourordersdelivereddate"><strong>Order Cancelled on <?php echo e(date('d M, Y', strtotime($order->updated_at))); ?><small> by <?php if($order->cancelledOrder->cancelledBy == config('constants.userType.user')): ?> You <?php else: ?> Skyline Admin <?php endif; ?></small></strong></p>

                            <?php $__empty_2 = true; $__currentLoopData = $order->orderProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderproduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>    
                                <div class="yourordersproduct">
                                    <div class="yourordersproductimg">
                                        <img src="<?php echo e(asset('images/'.$orderproduct->product->image)); ?>" alt="">
                                    </div>

                                    <div class="yourordersproductinfo">
                                        <p class="mb-0 yourordersprodname"><?php echo e($orderproduct->product->name); ?></p>
                                        <p class="mb-1 text-secondary small">Qty: <?php echo e($orderproduct->quantity); ?></p>
                                        <p class="mb-1 text-secondary small">Variant: <?php echo e($orderproduct->varient->name); ?></p>
                                        <p class="mb-0 fw-bold text-success">₹<?php echo e($orderproduct->product->sellingPrice); ?></p>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                
                            <?php endif; ?>
                        </div>

                    </div>
                    <?php echo e($order->cancelledOrder->cancelledBy); ?>

                    <?php if($order->cancelledOrder->cancelledBy == config('constants.userType.user')): ?>
                        <div class="mb-3 p-3">
                            <div class="mb-3">
                                <label class="form-label small">Your reason to cancel order :</label>
                                <textarea class="form-control form-control-sm" id="exampleFormControlTextarea1" rows="7"
                                    disabled><?php echo e($order->cancelledOrder->reason); ?></textarea>
                            </div>
                            <?php if($order->cancelledOrder->reply): ?>
                                <div class="mb-3">
                                    <label class="form-label small">Skyline's Reply :</label>
                                    <textarea class="form-control form-control-sm" id="exampleFormControlTextarea1" rows="7"
                                        disabled><?php echo e($order->cancelledOrder->reply); ?></textarea>
                                </div>
                            <?php else: ?>
                                <p>Skyline admin not replied yet</p>
                            <?php endif; ?>
                            
                        </div>
                    <?php else: ?>
                        <div class="mb-3 p-3">
                            <div class="mb-3">
                                <label class="form-label small">Skyline's Reply :</label>
                                <textarea class="form-control form-control-sm" id="exampleFormControlTextarea1" rows="7"
                                    disabled><?php echo e($order->cancelledOrder->reason); ?></textarea>
                            </div>
                        </div>
                    <?php endif; ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                
            <?php endif; ?>
            <!-- order returned ends
        </div>
        <!-- your orders end -->
    </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['header' => 'small', 'footer' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adina\Desktop\skyline\resources\views/orders/cancel/index.blade.php ENDPATH**/ ?>