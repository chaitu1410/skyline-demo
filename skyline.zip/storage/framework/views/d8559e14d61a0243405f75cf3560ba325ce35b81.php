

<?php $__env->startSection('content'); ?>
    <!-- Page content-->
    <div class="container-fluid">



        <div class="allcontents bg-white p-2 mt-2">

            <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
                <ol class="breadcrumb breadcrumblinks">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Cities and Pincodes</li>
                </ol>
            </nav>
            <!-- <div class="panelheading">
                <p>Users</p>
            </div> -->


            <div class="dataaddactions mb-4">

                <div class="addcategorybtns">
                    <button class="btn bluebg btn-sm" data-bs-toggle="modal" data-bs-target="#addcitymodal">+
                        Add City</button>
                </div>
                <!-- searchbar -->
                <div id="datasearchbar" class="input-group mt-3 mb-3">
                    <input type="text" class="form-control" placeholder="Search Cities"
                        aria-label="Recipient's username" aria-describedby="button-addon2">
                    <button class="btn orangebg" type="button" id="button-addon2">
                        <span class="material-icons">
                            search
                        </span>
                    </button>
                </div>
            </div>

            <!-- table -->
            <div id="alldatatable" class="bg-white mt-2">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>State</th>
                            <th>City</th>
                            <th>Pincode</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>12345</td>
                            <td>Maharashtra</td>
                            <td>Aurangabad</td>
                            <td>431001</td>
                            <td>
                                <div class="d-flex">
                                    <button class="btn bluebg btn-sm" data-bs-toggle="modal"
                                        data-bs-target="#editcitymodal">
                                        <span class="material-icons">
                                            edit
                                        </span>
                                    </button>

                                    <button class="btn btn-danger btn-sm" data-bs-toggle="modal"
                                        data-bs-target="#deleteconfirmmodal">
                                        <span class="material-icons">
                                            delete
                                        </span>
                                    </button>
                                </div>

                            </td>
                        </tr>
                        <!--modal for edit city starts -->
                        <div class="modal fade" id="editcitymodal" tabindex="-1" aria-labelledby="editcitymodalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-scrollable">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Edit Brand</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="mb-3">
                                            <label for="exampleFormControlInput1" class="form-label">State
                                                Name</label>
                                            <select class="form-select form-select-sm" aria-label=".form-select-sm example">
                                                <option selected>India</option>
                                                <option value="1">One</option>
                                                <option value="2">Two</option>
                                                <option value="3">Three</option>
                                            </select>
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleFormControlInput1" class="form-label">City
                                                Name</label>
                                            <select class="form-select form-select-sm" aria-label=".form-select-sm example">
                                                <option selected>Aurangabad</option>
                                                <option value="1">One</option>
                                                <option value="2">Two</option>
                                                <option value="3">Three</option>
                                            </select>
                                        </div>
                                        <div class="mb-3">
                                            <label for="exampleFormControlInput1" class="form-label">
                                                Pincode
                                            </label>
                                            <input type="number" class="form-control form-control-sm" id="exampleFormControlInput1"
                                                value="431001">
                                        </div>

                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn bluebg btn-sm">Update City</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--modal for edit city ends-->


                        <!--modal for delete confirm starts -->
                        <div class="modal fade" id="deleteconfirmmodal" tabindex="-1" aria-labelledby="deleteconfirmmodalLabel"
                            aria-hidden="true">
                            <div class="modal-dialog modal-sm">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Delete City</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">

                                        <div class="mb-3">
                                            <p>Are you sure that you want to delete ?</p>
                                        </div>

                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger btn-sm">Confirm Delete</button>
                                    </div>

                                </div>
                            </div>
                        </div>
                        <!--modal for delete confirm ends-->
                    </tbody>
                </table>




            </div>

            <!-- pagination -->
            <nav aria-label="Page navigation example">
                <ul class="pagination pagination-sm justify-content-end">
                    <li class="page-item">
                        <a class="page-link" href="#" aria-label="Previous">
                            <span aria-hidden="true">&laquo;</span>
                        </a>
                    </li>
                    <li class="page-item active" aria-current="page">
                        <span class="page-link">1</span>
                    </li>
                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                    <li class="page-item">
                        <a class="page-link" href="#" aria-label="Next">
                            <span aria-hidden="true">&raquo;</span>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>

    </div>
    <!-- Page content ends-->

    <!-- add city modal starts -->
    <div class="modal fade" id="addcitymodal" tabindex="-1" aria-labelledby="addcitymodalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add City</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">State
                            Name</label>
                        <select class="form-select form-select-sm" aria-label=".form-select-sm example">
                            <option selected>Open this select menu</option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">City
                            Name</label>
                        <select class="form-select form-select-sm" aria-label=".form-select-sm example">
                            <option selected>Open this select menu</option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="exampleFormControlInput1" class="form-label">
                            Pincode
                        </label>
                        <input type="number" class="form-control form-control-sm" id="exampleFormControlInput1">
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn bluebg btn-sm">Add/Save City</button>
                </div>
            </div>
        </div>
    </div>
    <!-- add city modal ends -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adina\Desktop\skyline\resources\views/admin/cities/index.blade.php ENDPATH**/ ?>