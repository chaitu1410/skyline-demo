<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <base href="<?php echo e(url('/')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(public_path('assets/css/style.css')); ?>">
    <title>Invoice</title>
</head>

<body>

    <style>
        .invoicecontainer {
            width: 60%;
            margin: 3% 20%;
            box-shadow: 3px 3px 10px lightgrey;
            padding: 2rem;
        }

        .invheadpart img {
            height: 3rem;
        }

        .invoicehead {
            display: flex;
            justify-content: space-between;
        }

        .invheadpart {
            text-align: right;
        }

        .invoicecontent {
            display: flex;
            justify-content: space-between;
        }

        .invoicecontentpart {
            width: 48%;
        }

        .invoicecontentpart1 {
            text-align: right;
        }

        .invoicetable table {
            border: 1px solid rgb(88, 88, 88);
            width: 100%;
        }

        .invoicesignaturediv {

            text-align: right;
        }

        .signaturediv {
            height: 3rem;
            width: 170px;
            margin-top: 0.7rem;
            margin-bottom: 0.7rem;
            margin-left: auto;
            background-color: lightgrey;
            text-align: center;
        }

        .signaturediv img {
            margin-top: 0.1rem;
            height: 2.8rem;
        }
        .invoiceverysmalltext{
            font-size: 9px;
            text-align: center;
        }
    </style>
    <section>
        <div class="invoicecontainer">
            <div class="invoicehead">
                <div class="invheadpart">
                    <strong>
                        <p class="mb-0">Tax Invoice/Bill of Supply/Cash Memo</p>
                    </strong>
                    <p>(Original for Recipient)</p>
                </div>
            </div>

            <div class="invoicecontent mt-5">
                <div class="invoicecontentpart">
                    <strong>
                        <small>
                            <p class="mb-0">Sold By :</p>
                        </small>
                    </strong>
                    <small>
                        <p class="mb-0">Skyline Distributors</p>
                    </small>
                    <small>
                        <?php echo e($sellerDetails->OfficeAddress); ?>

                    </small>
                </div>

                <div class="invoicecontentpart invoicecontentpart1">
                    <strong>
                        <small>
                            <p>Billing Address :</p>
                        </small>
                    </strong>
                    <small>
                        <p><?php echo e($details->customerName); ?></p>
                    </small>
                    <small>
                        <p>
                            <?php echo e($details->houseNumber); ?>, <?php echo e($details->landmark); ?>, <?php echo e($details->area); ?>

                        </p>
                    </small>
                    <small>
                        <p><?php echo e($details->town); ?>, <?php echo e($pincode->state); ?>, <?php echo e($details->pincode); ?></p>
                    </small>
                    <small>
                        <p>INDIA</p>
                    </small>

                </div>
            </div>

            <div class="invoicecontent">
                <div class="invoicecontentpart">

                    <p><small><strong>PAN No :</strong> AAQCS4259Q</small></p>
                    <p><small><strong>GST Registration No :</strong> 27AAQCS4259Q1ZA</small></p>
                </div>

                <div class="invoicecontentpart invoicecontentpart1">
                    <strong>
                        <small>
                            <p class="mb-0">Shipping Address :</p>
                        </small>
                    </strong>
                    <small>
                        <p class="mb-0"><?php echo e($details->customerName); ?></p>
                    </small>
                    <small>
                        <p class="mb-0">
                            <?php echo e($details->houseNumber); ?>, <?php echo e($details->landmark); ?>, <?php echo e($details->area); ?>

                        </p>
                    </small>
                    <small>
                        <p class="mb-0"><?php echo e($details->town); ?>, <?php echo e($pincode->state); ?>, <?php echo e($details->pincode); ?></p>
                    </small>
                    <small>
                        <p class="mb-0">INDIA</p>
                    </small>
                    <p class="mb-0"><small><strong>Place of delivery :</strong> <?php echo e($pincode->state); ?></small></p>
                </div>
            </div>

            <div class="invoicecontent mt-5">
                <div class="invoicecontentpart">

                    <p class="mb-0"><small><strong>Order Number :</strong> <?php echo e($order->id); ?></small></p>
                    <p class="mb-0"><small><strong>Order Date :</strong> <?php echo e(date('d M, Y', strtotime($order->created_at))); ?></small></p>
                </div>

                <div class="invoicecontentpart invoicecontentpart1">


                    <p class="mb-0"><small><strong>Invoice Number :</strong> <?php echo e($order->id); ?> </small></p>
                    <p class="mb-0"><small><strong>Invoice Details :</strong> <?php echo e($order->id); ?></small></p>
                    <p class="mb-0"><small><strong>Invoice Date :</strong> <?php echo e(date('d M, Y', strtotime($order->created_at))); ?></small></p>

                </div>
            </div>

            <div class="invoicetable mt-5">
                <table class="table table-bordered small">
                    <thead>
                        <tr>
                            <th scope="col">Sr. No.</th>
                            <th scope="col">Description</th>
                            <th scope="col">Unit Price</th>
                            <th scope="col">Qty</th>
                            <th scope="col">Net Amount</th>
                            <th scope="col">Tax Rate</th>
                            <th scope="col">Tax Type</th>
                            <th scope="col">Tax Amount</th>
                            <th scope="col">Total Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>    
                            <tr>
                                <th scope="row"><?php echo e($index+1); ?></th>
                                <td>
                                    <?php echo e($product->product->name); ?><br>Varient: <?php echo e($product->varient->name); ?>

                                </td>
                                <td>₹<?php echo e($product->varient->mrp); ?></td>
                                <td><?php echo e($product->quantity); ?></td>
                                <td>₹<?php echo e($product->varient->mrp * $product->quantity); ?></td>
                                <td><?php echo e($product->varient->gst); ?>%</td>
                                <td>IGST</td>
                                <td>₹<?php echo e($product->varient->gstAmount()); ?></td>
                                <td>₹<?php echo e($product->varient->sellingPrice); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            
                        <?php endif; ?>

                        <tr>
                            <th scope="row" colspan="7">Total :</th>
                            <td>₹<?php echo e($details->totalGst); ?></td>
                            <td>₹<?php echo e($details->payableAmount + $details->totalDiscount - $details->deliveryCharge); ?></td>
                        </tr>

                        <tr>
                            <th scope="row" colspan="8">Total Discount :</th>
                            <td>₹<?php echo e($details->totalDiscount); ?></td>
                        </tr>

                        <tr>
                            <th scope="row" colspan="8">Delivery Charge :</th>
                            <td>₹<?php echo e($details->deliveryCharge); ?></td>
                        </tr>

                        <tr>
                            <th scope="row" colspan="8">Total Payable Amount :</th>
                            <td>₹<?php echo e($details->payableAmount); ?></td>
                        </tr>

                        <tr>
                            <th scope="row" colspan="9">
                                <p class="mb-0">Amount in Words:
                                </p>
                                <p class="mb-0"> <?php echo e(numberTowords($details->payableAmount)); ?></p>
                            </th>
                        </tr>

                        <tr>
                            <th scope="row" colspan="9">
                                <div class="invoicesignaturediv">
                                    <p class="mb-0">For Skyline Distributors :
                                    </p>
                                    <div class="signaturediv">
                                        <img src="<?php echo e(asset("assets/images/sign.jpg")); ?>" alt="">
                                    </div>
                                    <p class="mb-0">Authorized Signatory
                                    </p>
                                </div>
                            </th>
                        </tr>
                    </tbody>
                </table>
            </div>

        </div>
    </section>

</body>

</html><?php /**PATH C:\Users\adina\Desktop\skyline\resources\views/orders/invoice.blade.php ENDPATH**/ ?>