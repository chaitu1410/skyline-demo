<div class="tab-pane fade show active" id="cat4" role="tabpanel" aria-labelledby="home-tab">
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Payment ID</th>
                <th>Customer Name</th>
               
                <th>Contact No.</th>
                <th>Ship To</th>
                <th>Status</th>

                <th>Purchased Products</th>
                <th>Purchased Price</th>
                <th>GST No.</th>
                <th>Trade/Company Name</th>
                <th>Ordered Date</th>
                
                <th>Reason</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                
                <tr>
                    <td><?php echo e($order->id); ?></td>
                    <td>#345678902345</td>
                    <td>
                        <div class="tablecellwidth">
                            <p class="mb-0"><?php echo e($order->orderDetail->customerName); ?></p>
                        </div>
                    </td>
                
                    <td><?php echo e($order->orderDetail->customerContact); ?></td>
                    <td>
                        <div class="tablecellwidth">
                            <p class="mb-0"><?php echo e($order->orderDetail->houseNumber); ?>, <?php echo e($order->orderDetail->landmark); ?>, <?php echo e($order->orderDetail->area); ?>, <?php echo e($order->orderDetail->town); ?>. <?php echo e($order->orderDetail->pincode); ?></p>
                        </div>
                    </td>
                    <td>
                        <?php if($order->cancelledOrder->cancelledBy == config('constants.userType.admin')): ?>
                            <span class="badge bg-primary">Canceled By Admin</span>
                        <?php elseif($order->cancelledOrder->cancelledBy == config('constants.userType.user')): ?>
                            <span class="badge bg-danger">Canceled By User</span>
                        <?php endif; ?>
                    </td>

                    <td>
                        <a href="#" data-bs-toggle="modal"
                            data-bs-target="#viewproductsmodal<?php echo e($order->id); ?>">View Products</a>
                    </td>

                    <td>₹<?php echo e($order->orderDetail->payableAmount); ?></td>
                    <td><?php echo e($order->orderDetail->gst); ?></td>
                    <td>
                        <div class="tablecellwidth">
                            <p class="mb-0"><?php echo e($order->orderDetail->company); ?></p>
                        </div>
                    </td>
                    <td><?php echo e(date('d M, Y', strtotime($order->created_at))); ?></td>
                    <td>
                        <?php if($order->cancelledOrder->cancelledBy == config('constants.userType.admin')): ?>
                            <a href="" data-bs-toggle="modal"
                            data-bs-target="#reasonreturnmodal<?php echo e($order->id); ?>">View</a>
                        <?php elseif($order->cancelledOrder->cancelledBy == config('constants.userType.user')): ?>
                            <a href="" data-bs-toggle="modal"
                            data-bs-target="#reasoncancelmodalwithreply<?php echo e($order->id); ?>">View & Reply</a>
                        <?php endif; ?>

                    </td>
                </tr>
                

                <!--modal for view products ordered starts -->
                <div class="modal fade" id="viewproductsmodal<?php echo e($order->id); ?>" tabindex="-1" aria-labelledby="viewproductsmodalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog modal-dialog-scrollable">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">skyline username</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">

                                <div class="d-flex mb-4 justify-content-between align-content-center">
                                    <h6 class="fw-bold">Purchased Products</h6>

                                </div>

                                <?php $__empty_2 = true; $__currentLoopData = $order->orderProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>    
                                    <div class="orderhistoryitem">
                                        <p class="mb-0">
                                            <a href=""><?php echo e($p->product->name); ?></a>
                                        </p>
                                        <p class="mb-0 text-success">₹<?php echo e($p->varient->sellingPrice); ?></p>
                                        <p class="mb-0 text-secondary">Qty: <?php echo e($p->quantity); ?></p>
                                        <p class="mb-0 text-secondary">Varient: <?php echo e($p->varient->name); ?></p>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                    
                                <?php endif; ?>

                                <h6 class="fw-bold">Total Amount: ₹<?php echo e($order->orderDetail->payableAmount); ?></h6>
                            </div>

                        </div>
                    </div>
                </div>
                <!--modal for view products ordered  ends-->

                <?php if($order->cancelledOrder->cancelledBy == config('constants.userType.admin')): ?>
                    <!--Cancelled by admin start -->
                    <div class="modal fade" id="reasonreturnmodal<?php echo e($order->id); ?>" tabindex="-1" aria-labelledby="reasonreturnmodalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">skyline username</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <div class="d-flex mb-3justify-content-between align-content-center">
                                    <h6 class="fw-bold">Reason For Cancelling Order</h6>
                                </div>
                                <div>
                                    <p><?php echo e($order->cancelledOrder->reason); ?></p>
                                </div>
                            </div>

                        </div>
                    </div>
                    </div>
                    <!--Cancelled by admin end-->
                <?php elseif($order->cancelledOrder->cancelledBy == config('constants.userType.user')): ?>
                    <!-- Cancelled by user start -->
                    <div class="modal fade" id="reasoncancelmodalwithreply<?php echo e($order->id); ?>" tabindex="-1" aria-labelledby="replyreturnmodalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog modal-dialog-scrollable modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">skyline username</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <form action="<?php echo e(route('admin.orders.cancelReply', $order)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <div class="modal-body">
                                    <div class="returnedproduct">
                                        <div>
                                            <p class="mb-0 fw-bold">Reason to cancel order :</p>
                                            <p><?php echo e($order->cancelledOrder->reason); ?></p>
                                        </div>
                                    </div>
                                    <hr>
        
                                    <p class="mb-3 fw-bold">Reply to User:</p>
                                    <div class="mb-3">
                                        <textarea class="form-control form-control-sm" name="reply" id="exampleFormControlTextarea1" rows="5"
                                            placeholder="Write your reply here..."><?php echo e($order->cancelledOrder->reply); ?></textarea>
                                    </div>
        
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn bluebg btn-sm">Send Message</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- Cancelled by user end -->
            <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>No cancelled orders.</p>
        <?php endif; ?>

        </tbody>
    </table>
</div><?php /**PATH C:\Users\adina\Desktop\skyline\resources\views/components/admin/cancelled-orders.blade.php ENDPATH**/ ?>