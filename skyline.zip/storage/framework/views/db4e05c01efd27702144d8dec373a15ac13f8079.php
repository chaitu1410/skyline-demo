 <!--shop by brands start-->
 <div id="shopbybrandsection">
    <div class="siteheading">
    <h6>
        Shop By Authorized Brands
    </h6>
    </div>
    <div class="headingunderline"></div>

    <div id="shopbybrands">
        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="shopbybranditem" onclick="location.href='<?php echo e(route('brands.show', $brand->slug)); ?>'">
                <img src="<?php echo e(asset('images/'.$brand->image)); ?>" alt="<?php echo e($brand->name); ?>" />
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</d>
<!--shop by brands end--><?php /**PATH C:\Users\adina\Desktop\skyline\resources\views/components/shop-by-brands.blade.php ENDPATH**/ ?>