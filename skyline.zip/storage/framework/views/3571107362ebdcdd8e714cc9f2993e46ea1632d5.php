

<?php $__env->startSection('ogtitle', 'Skyline Distributors | Aurangabad'); ?>
<?php $__env->startSection('title', 'Skyline Distributors | Aurangabad - Details'); ?>

<?php $__env->startSection('content'); ?>

<!-- breadcrumb start -->
<nav id="breadcrumbproductinfo" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb" class="pb-0">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('categories.index')); ?>">All Categories</a></li>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e($category->name); ?></li>
    </ol>
</nav>
<!-- breadcrumb ends -->

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('category-product-list', ['query' => $query, 'category' => $category->id])->html();
} elseif ($_instance->childHasBeenRendered('8kwNOvS')) {
    $componentId = $_instance->getRenderedChildComponentId('8kwNOvS');
    $componentTag = $_instance->getRenderedChildComponentTagName('8kwNOvS');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('8kwNOvS');
} else {
    $response = \Livewire\Livewire::mount('category-product-list', ['query' => $query, 'category' => $category->id]);
    $html = $response->html();
    $_instance->logRenderedChild('8kwNOvS', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['header' => 'full', 'footer' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adina\Desktop\skyline\resources\views/categories/show.blade.php ENDPATH**/ ?>