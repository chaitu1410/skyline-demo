

<?php $__env->startSection('ogtitle', 'Skyline Distributors | Aurangabad'); ?>
<?php $__env->startSection('title', $brand->name); ?>

<?php $__env->startSection('content'); ?>

<!-- breadcrumb start -->
<nav id="breadcrumbproductinfo" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb" class="pb-0">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
        <li class="breadcrumb-item"><?php echo e($brand->name); ?></li>
    </ol>
</nav>
<!-- breadcrumb ends -->


<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('brand-product-list', ['query' => $query, 'brand' => $brand->id])->html();
} elseif ($_instance->childHasBeenRendered('qLsCp5P')) {
    $componentId = $_instance->getRenderedChildComponentId('qLsCp5P');
    $componentTag = $_instance->getRenderedChildComponentTagName('qLsCp5P');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qLsCp5P');
} else {
    $response = \Livewire\Livewire::mount('brand-product-list', ['query' => $query, 'brand' => $brand->id]);
    $html = $response->html();
    $_instance->logRenderedChild('qLsCp5P', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['header' => 'full', 'footer' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adina\Desktop\skyline\resources\views/brands/show.blade.php ENDPATH**/ ?>