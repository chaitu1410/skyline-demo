<div class="tab-pane fade show active" id="cat5" role="tabpanel" aria-labelledby="home-tab">
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Payment ID</th>
                <th>Customer Name</th>
           
                <th>Contact No.</th>
                <th>Pickup Address</th>

                <th>Returned Products</th>
                <th>Purchased Price</th>
                <th>Delivery Charge</th>
                <th>Return Amount</th>
                <th>GST No.</th>
                <th>Trade/Company Name</th>
                <th>Ordered Date</th>
                <th>Reason</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $returnorders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $returnorder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($returnorder->id); ?></td>
                    <td>#345678902345</td>
                    <td>
                        <div class="tablecellwidth">
                            <p class="mb-0"><?php echo e($returnorder->order->orderDetail->customerName); ?></p>
                        </div>
                    </td>
                
                    <td><?php echo e($returnorder->order->orderDetail->customerContact); ?></td>
                    <td>
                        <div class="tablecellwidth">
                            <p class="mb-0"><?php echo e($returnorder->order->orderDetail->houseNumber); ?>, <?php echo e($returnorder->order->orderDetail->landmark); ?>, <?php echo e($returnorder->order->orderDetail->area); ?>, <?php echo e($returnorder->order->orderDetail->town); ?>. <?php echo e($returnorder->order->orderDetail->pincode); ?></p>
                        </div>
                    </td>

                    <td>
                        <a href="#" data-bs-toggle="modal"
                            data-bs-target="#viewproductsmodal<?php echo e($returnorder->id); ?>">View Products</a>
                    </td>

                    <td>₹<?php echo e($returnorder->order->orderDetail->payableAmount); ?></td>
                    <td>₹<?php echo e($returnorder->order->orderDetail->deliveryCharge); ?></td>
                    <td>₹<?php echo e($returnorder->returnAmount); ?></td>
                    <td><?php echo e($returnorder->order->orderDetail->gst); ?></td>
                    <td>
                        <div class="tablecellwidth">
                            <p class="mb-0"><?php echo e($returnorder->order->orderDetail->company); ?></p>
                        </div>
                    </td>
                    <td><?php echo e(date('d M, Y', strtotime($returnorder->order->created_at))); ?></td>
                    <td>
                        <a href="" data-bs-toggle="modal"
                            data-bs-target="#reasonreturnmodalwithreply<?php echo e($returnorder->id); ?>">View & Reply</a>

                    </td>

                </tr>

                <!--modal for view products returned starts -->
                <div class="modal fade" id="viewproductsmodal<?php echo e($returnorder->id); ?>" tabindex="-1" aria-labelledby="viewproductsmodalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog modal-dialog-scrollable">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">skyline username</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">

                                <div class="d-flex mb-4 justify-content-between align-content-center">
                                    <h6 class="fw-bold">Returned Products</h6>

                                </div>

                                <?php $__empty_2 = true; $__currentLoopData = $returnorder->returnOrderProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>    
                                    <div class="orderhistoryitem">
                                        <p class="mb-0">
                                            <a href=""><?php echo e($p->orderProduct->product->name); ?></a>
                                        </p>
                                        <p class="mb-0 text-success">₹<?php echo e($p->orderProduct->varient->sellingPrice); ?></p>
                                        <p class="mb-0 text-secondary">Varient: <?php echo e($p->orderProduct->varient->name); ?></p>
                                        <p class="mb-0 text-secondary">Qty: <?php echo e($p->orderProduct->quantity); ?></p>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                    
                                <?php endif; ?>

                                <h6 class="fw-bold">Total Amount: ₹<?php echo e($p->orderProduct->varient->sellingPrice * $p->orderProduct->quantity); ?></h6>
                            </div>

                        </div>
                    </div>
                </div>
                <!--modal for view products returned ends-->
                
                <!--modal for reply to return by user starts -->
                <div class="modal fade" id="reasonreturnmodalwithreply<?php echo e($returnorder->id); ?>" tabindex="-1" aria-labelledby="replyreturnmodalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-dialog-scrollable modal-lg">
                    <form action="<?php echo e(route('admin.orders.returnReply', $returnorder->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>

                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel"><?php echo e($returnorder->order->customerName); ?></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div> 
                            <div class="modal-body">
                                <div class="d-flex mb-3justify-content-between align-content-center mt-3 mb-2">
                                    <h6 class="fw-bold">Returned Products :</h6>
                                </div>
                                <?php $__empty_2 = true; $__currentLoopData = $returnorder->returnOrderProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>  
                                    <div class="returnedproduct">
                                        <div class="orderhistoryitem">
                                            <p class="mb-0">
                                                <strong>Product</strong>
                                                <a href=""><?php echo e($p->orderProduct->product->name); ?></a>
                                            </p>
                                            <p class="mb-0 text-secondary">Variant: <?php echo e($p->orderProduct->varient->name); ?></p>
                                            <p class="mb-0 text-success">₹ <?php echo e($p->orderProduct->varient->sellingPrice); ?></p>
                                            <p class="mb-0 text-secondary">Qty: <?php echo e($p->orderProduct->quantity); ?></p>
                                        </div>
                                        <div>
                                            <p class="mb-0 fw-bold">Reason to return :</p>
                                            <p><?php echo e($p->reason); ?></p>
                                            <p class="mb-0 fw-bold">Detailed Reason :</p>
                                            <p><?php echo e($p->detailedReason); ?></p>
                                        </div>
                                        <div class="mt-3 mb-3">
                                            <p class="mb-2 fw-bold">Reply to User:</p>
                                            <input type="hidden" name="returnorderproducts[]" value="<?php echo e($p->id); ?>">
                                            <textarea class="form-control form-control-sm" id="exampleFormControlTextarea1" rows="5"
                                                placeholder="Write your reply here..." name="replies[]"><?php echo e($p->reply); ?></textarea>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                            
                                <?php endif; ?>
                                <hr>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn bluebg btn-sm">Send Message</button>
                            </div>
                        </div>
                    </form>
                </div>
                </div>
            <!--modal for reply to return by user ends-->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>No returned orders.</p>
           <?php endif; ?>
        </tbody>

    </table>
</div>


                

</div><?php /**PATH C:\Users\adina\Desktop\skyline\resources\views/components/admin/returned-orders.blade.php ENDPATH**/ ?>