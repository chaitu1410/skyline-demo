

<?php $__env->startSection('content'); ?>
    <!-- Page content-->
    <div class="container-fluid">

        <div class="allcontents bg-white p-2 mt-2">

            <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
                <ol class="breadcrumb breadcrumblinks">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Questions Asked</li>
                </ol>
            </nav>


            <!-- table -->
            <div id="alldatatable" class="bg-white mt-2 pt-3">

                <p class="fw-bold">Total Questions : <?php echo e(count($questions)); ?></p>
                <?php $__empty_1 = true; $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="faqitem">
                        <p class="fw-bold mb-0">Question - <?php echo e($index+1); ?></p>
                        <div class="faq-prodname">
                            <a href="<?php echo e(route('products.show', $question->product)); ?>" class="mb-1"><?php echo e($question->product->name); ?></a>
                        </div>
                        <form action="<?php echo e(route('admin.questions.update', $question)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <div class="faq-questans">
                                <label for="exampleFormControlTextarea1" class="form-label"><?php echo e($question->question); ?> <br> <small>By <?php echo e($question->user->name); ?> (<?php echo e($question->created_at->diffForHumans()); ?>)</small></label>
                                <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"
                                    placeholder="Write Your Answer Here..." name="answer"><?php echo e(old('answer')); ?></textarea>
                            </div>
                            <div class="faq-postans mt-2">
                                <button class="btn btn-sm orangebg" type="submit">Post Answer</button>
                            </div>
                        </form>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                   <p>No unanswered questions available</p> 
                <?php endif; ?>

            <!-- pagination -->
            <nav aria-label="Page navigation example">
                <ul class="pagination pagination-sm justify-content-end">
                    <?php echo e($questions->links('pagination::bootstrap-4')); ?>

                </ul>
            </nav>
        </div>

    </div>
    <!-- Page content ends-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adina\Desktop\skyline\resources\views/admin/questions/index.blade.php ENDPATH**/ ?>