<form action="" method="post">
    <?php echo csrf_field(); ?>
    <div class="modal-body">
        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">State
                Name</label>
            <select id="states" name="state" class="form-select form-select-sm" aria-label=".form-select-sm example" readonly>
                <option>Open this select menu</option>
                <option selected value="<?php echo e($selectedState); ?>"><?php echo e($selectedState); ?></option>    
            </select>
        </div>
        <?php if($selectedState): ?>     
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">City
                    Name</label>
                <select id="cities" name="city" class="form-select form-select-sm" aria-label=".form-select-sm example" readonly>  
                    <option>Open this select menu</option>
                    <option selected value="<?php echo e($selectedCity); ?>"><?php echo e($selectedCity); ?></option>    
                </select>
            </div>
        <?php endif; ?>

        <?php if($selectedCity): ?>    
            <div class="mb-3">
                <label for="exampleFormControlInput1" class="form-label">
                    Pincode
                </label>
                <input type="number" name="pincode" class="form-control form-control-sm" id="exampleFormControlInput1" wire:model="pincode" value="<?php echo e($pincode); ?>">
                <?php if(session()->has('error')): ?>
                    <span class="text-danger">
                        <?php echo e(session('error')); ?>

                    </span>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
    <?php if($validPincode): ?>    
        <div class="modal-footer">
            <button type="submit" class="btn bluebg btn-sm">Add/Save City</button>
        </div>
    <?php endif; ?>
</form>
<?php /**PATH C:\Users\adina\Desktop\skyline\resources\views/livewire/admin/edit-pincode-form.blade.php ENDPATH**/ ?>