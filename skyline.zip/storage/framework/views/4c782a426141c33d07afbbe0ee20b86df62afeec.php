

<?php $__env->startSection('ogtitle', 'Skyline Distributors | Aurangabad'); ?>
<?php $__env->startSection('title', 'Skyline Distributors | Aurangabad - Categories'); ?>

<?php $__env->startSection('content'); ?>

<!-- categories start -->
<section>
    <div id="allcategoriescont">

        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>    
            <div class="categoryitem card" onclick="location.href='<?php echo e(route('categories.show', $category)); ?>'">
                <div class="categoryimg">
                    <img src="<?php echo e(asset('images/'.$category->image )); ?>" alt="<?php echo e($category->name); ?>">
                </div>
                <div class="categoryname">
                    <p class="mb-0"><?php echo e($category->name); ?></p>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>Categories not added</p>
        <?php endif; ?>


    </div>
</section>
<!-- categories end -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.special', ['headertitle' => 'All Categories', 'footer' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adina\Desktop\skyline\resources\views/categories/index.blade.php ENDPATH**/ ?>