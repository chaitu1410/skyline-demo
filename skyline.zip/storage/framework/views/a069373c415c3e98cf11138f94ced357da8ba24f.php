

<?php $__env->startSection('content'); ?>
<!-- Page content-->
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.add-varient')->html();
} elseif ($_instance->childHasBeenRendered('NrAZiL2')) {
    $componentId = $_instance->getRenderedChildComponentId('NrAZiL2');
    $componentTag = $_instance->getRenderedChildComponentTagName('NrAZiL2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('NrAZiL2');
} else {
    $response = \Livewire\Livewire::mount('admin.add-varient');
    $html = $response->html();
    $_instance->logRenderedChild('NrAZiL2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<!-- Page content ends-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adina\Desktop\skyline\resources\views/admin/products/addVarient.blade.php ENDPATH**/ ?>