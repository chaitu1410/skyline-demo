

<?php $__env->startSection('ogtitle', 'Skyline Distributors | Aurangabad'); ?>
<?php $__env->startSection('title', 'Your Cart'); ?>

<?php $__env->startSection('content'); ?>

    <!-- breadcrumb start -->
  <nav id="breadcrumbproductinfo" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.html">Home</a></li>
      <li class="breadcrumb-item active" aria-current="page">Your Cart</li>

    </ol>
  </nav>
  <!-- breadcrumb ends -->

  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('cart-list')->html();
} elseif ($_instance->childHasBeenRendered('SwLVojX')) {
    $componentId = $_instance->getRenderedChildComponentId('SwLVojX');
    $componentTag = $_instance->getRenderedChildComponentTagName('SwLVojX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('SwLVojX');
} else {
    $response = \Livewire\Livewire::mount('cart-list');
    $html = $response->html();
    $_instance->logRenderedChild('SwLVojX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['header' => 'small', 'footer' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adina\Desktop\skyline\resources\views/carts/index.blade.php ENDPATH**/ ?>