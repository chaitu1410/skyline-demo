

<?php $__env->startSection('content'); ?>
    <!-- Page content-->
    <div class="container-fluid">

        <div class="allcontents bg-white p-2 mt-2">

            <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
                <ol class="breadcrumb breadcrumblinks">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Order Status</li>
                </ol>
            </nav>


            <div class="dataaddactions">
                <div class="addcategorybtns btn-group">
                    <button class="btn btn-secondary btn-sm" onclick="location.href=''">Print</button>
                    <button class="btn btn-secondary btn-sm" onclick="location.href=''">Download PDF</button>
                </div>
                <!-- searchbar -->
                <form action="<?php echo e(route('admin.orders.index')); ?>">
                    <div id="datasearchbar" class="input-group mt-3 mb-3">
                        <input type="hidden" name="status" value="<?php echo e($status); ?>">
                        <input type="text" class="form-control" placeholder="Search Orders"
                        aria-label="Recipient's username" aria-describedby="button-addon2" name="query">
                        <button class="btn orangebg" type="submit" id="button-addon2">
                            <span class="material-icons">
                                search
                            </span>
                        </button>
                    </div>
                </form>
            </div>


            <!-- table -->
            <div class="bg-white mt-2">

                <div id="catvisetabs" class="mt-2">
                    <ul class="nav nav-tabs" id="tabcategory" role="tablist">

                        <li class="nav-item" role="presentation">
                            <button class="nav-link <?php if($status == config('constants.orderStatus.ordered')): ?> active <?php endif; ?> categorytabhead" data-bs-toggle="tab"
                                data-bs-target="#cat1" type="button" role="tab" aria-controls="cat1"
                                aria-selected="true" onclick="location.href='<?php echo e(route('admin.orders.index', ['status' => config('constants.orderStatus.ordered')])); ?>'">New Orders</button>
                        </li>

                        <li class="nav-item" role="presentation">
                            <button class="nav-link categorytabhead <?php if(!($status == config('constants.orderStatus.ordered')) && !($status == config('constants.orderStatus.delivered')) && !($status == config('constants.orderStatus.cancelled')) && !($status == config('constants.orderStatus.returned'))): ?> active <?php endif; ?>" data-bs-toggle="tab" data-bs-target="#cat2"
                                type="button" role="tab" aria-controls="cat1" aria-selected="true" onclick="location.href='<?php echo e(route('admin.orders.index', ['status' => config('constants.orderStatus.accepted')])); ?>'">Orders In
                                Progress</button>
                        </li>

                        <li class="nav-item" role="presentation">
                            <button class="nav-link categorytabhead <?php if($status == config('constants.orderStatus.delivered')): ?> active <?php endif; ?>" data-bs-toggle="tab" data-bs-target="#cat3"
                                type="button" role="tab" aria-controls="cat1" aria-selected="true" onclick="location.href='<?php echo e(route('admin.orders.index', ['status' => config('constants.orderStatus.delivered')])); ?>'">
                                Delivered Orders</button>
                        </li>

                        <li class="nav-item" role="presentation">
                            <button class="nav-link categorytabhead <?php if($status == config('constants.orderStatus.cancelled')): ?> active <?php endif; ?>" data-bs-toggle="tab" data-bs-target="#cat3"
                                type="button" role="tab" aria-controls="cat1" aria-selected="true" onclick="location.href='<?php echo e(route('admin.orders.index', ['status' => config('constants.orderStatus.cancelled')])); ?>'">
                                Cancelled Orders</button>
                        </li>

                        <li class="nav-item" role="presentation">
                            <button class="nav-link categorytabhead <?php if($status == config('constants.orderStatus.returned')): ?> active <?php endif; ?>" data-bs-toggle="tab" data-bs-target="#cat3"
                                type="button" role="tab" aria-controls="cat1" aria-selected="true" onclick="location.href='<?php echo e(route('admin.orders.index', ['status' => config('constants.orderStatus.returned')])); ?>'">
                                Returned Orders</button>
                        </li>
                    </ul>
                </div>

                <div id="alldatatable" class="tab-content pt-4" id="proTabContent">

                    <?php if($status == config('constants.orderStatus.ordered')): ?>
                        <?php if (isset($component)) { $__componentOriginal05194beca110bbc44ad2a59e5bd54e86601b9f4e = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\NewOrders::class, ['query' => $query]); ?>
<?php $component->withName('admin.new-orders'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal05194beca110bbc44ad2a59e5bd54e86601b9f4e)): ?>
<?php $component = $__componentOriginal05194beca110bbc44ad2a59e5bd54e86601b9f4e; ?>
<?php unset($__componentOriginal05194beca110bbc44ad2a59e5bd54e86601b9f4e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <?php elseif($status == config('constants.orderStatus.delivered')): ?>
                        <?php if (isset($component)) { $__componentOriginal457fb174fe0e578d611974df2c12b9cf01453460 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\DeliveredOrders::class, ['query' => $query]); ?>
<?php $component->withName('admin.delivered-orders'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal457fb174fe0e578d611974df2c12b9cf01453460)): ?>
<?php $component = $__componentOriginal457fb174fe0e578d611974df2c12b9cf01453460; ?>
<?php unset($__componentOriginal457fb174fe0e578d611974df2c12b9cf01453460); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <?php elseif($status == config('constants.orderStatus.cancelled')): ?>
                        <?php if (isset($component)) { $__componentOriginal8a745d9fcf5b9df01389b3daab33bf7119160d95 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\CancelledOrders::class, ['query' => $query]); ?>
<?php $component->withName('admin.cancelled-orders'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal8a745d9fcf5b9df01389b3daab33bf7119160d95)): ?>
<?php $component = $__componentOriginal8a745d9fcf5b9df01389b3daab33bf7119160d95; ?>
<?php unset($__componentOriginal8a745d9fcf5b9df01389b3daab33bf7119160d95); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <?php elseif($status == config('constants.orderStatus.returned')): ?>
                        <?php if (isset($component)) { $__componentOriginal20b61e84eefdead443e7c49c76b3643aa4d9991f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\ReturnedOrders::class, ['query' => $query]); ?>
<?php $component->withName('admin.returned-orders'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal20b61e84eefdead443e7c49c76b3643aa4d9991f)): ?>
<?php $component = $__componentOriginal20b61e84eefdead443e7c49c76b3643aa4d9991f; ?>
<?php unset($__componentOriginal20b61e84eefdead443e7c49c76b3643aa4d9991f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <?php else: ?>
                        <?php if (isset($component)) { $__componentOriginal10c0ce2ed00d31c529f2ef804c95b9ef5878954c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\OrdersInProgress::class, ['query' => $query]); ?>
<?php $component->withName('admin.orders-in-progress'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal10c0ce2ed00d31c529f2ef804c95b9ef5878954c)): ?>
<?php $component = $__componentOriginal10c0ce2ed00d31c529f2ef804c95b9ef5878954c; ?>
<?php unset($__componentOriginal10c0ce2ed00d31c529f2ef804c95b9ef5878954c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                    <?php endif; ?>

                </div>

            </div>

            
        </div>

    </div>
    <!-- Page content ends-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adina\Desktop\skyline\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>