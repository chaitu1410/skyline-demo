

<?php $__env->startSection('ogtitle', 'Skyline Distributors | Aurangabad'); ?>
<?php $__env->startSection('title', 'Your Orders'); ?>

<?php $__env->startSection('content'); ?>

<!-- breadcrumb start -->
<nav id="breadcrumbproductinfo" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.html">Home</a></li>
      <li class="breadcrumb-item active" aria-current="page">Your Orders</li>

    </ol>
  </nav>
  <!-- breadcrumb ends -->


  <section>
    <!-- your orders start -->

    <div id="yourcartheading">
      <div class="siteheading">
        <h6>
          Your Orders
        </h6>
      </div>
      <div class="headingunderline"></div>
    </div>

    <div id="assistanthelpsection">
      <div class="assistanthelpitem">
        <div>
          <img id="assistanthelpimg" src="<?php echo e(asset('assets/images/assistant.png')); ?>" alt="">
        </div>
        <div>
          <button class="btn bluebg">Request Bulk Quote Now</button>

        </div>
      </div>
      <div class="assistanthelpitem">
        <img src="<?php echo e(asset('assets/images/approved.png')); ?>" alt="">
      </div>
    </div>


    <div id="yourorderscont">

      <!-- order delivered -->
      <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="yourordersitem">
            <div class="yourordersitemheader">
                <div class="yourordersitemheaderitem">
                    <p class="mb-0 fw-bold">ORDER <?php if($order->status !== config('constants.orderStatus.outForDelivery')): ?> <?php echo e(strtoupper($order->status)); ?> <?php else: ?> OUT FOR DELIVERY <?php endif; ?></p>
                    <p class="mb-0 fw-bold"><?php echo e(date('d M, Y', strtotime($order->updated_at))); ?></p>
                </div>
                <?php if($order->status == config('constants.orderStatus.cancelled')): ?>
                    <div class="yourordersitemheaderitem">
                        <p class="mb-0">CANCELLED ON</p>
                        <p class="mb-0"><?php echo e(date('d M, Y', strtotime($order->updated_at))); ?></p>
                    </div>
                <?php elseif($order->status == config('constants.orderStatus.returned')): ?>
                    <div class="yourordersitemheaderitem">
                        <p class="mb-0">RETURNED ON</p>
                        <p class="mb-0"><?php echo e(date('d M, Y', strtotime($order->updated_at))); ?></p>
                    </div>
                <?php elseif($order->status !== config('constants.orderStatus.delivered')): ?>
                    <div class="yourordersitemheaderitem">
                        <p class="mb-0">ESTIMATED DELIVERY</p>
                        <p class="mb-0"><?php echo e(date('d M, Y', strtotime($order->estimatedDate))); ?></p>
                    </div>
                <?php else: ?>
                    <div class="yourordersitemheaderitem">
                        <p class="mb-0">DELIVERED ON</p>
                        <p class="mb-0"><?php echo e(date('d M, Y', strtotime($order->delivered_at))); ?></p>
                    </div>
                <?php endif; ?>

                <div class="yourordersitemheaderitem">
                    <p class="mb-0">TOTAL</p>
                    <p class="mb-0">₹<?php echo e($order->orderDetail->payableAmount); ?></p>
                </div>

                <div class="yourordersitemheaderitem">
                    <p class="mb-0">SHIP TO</p>
                    <p class="mb-0 text-primary"><?php echo e($order->orderDetail->customerName); ?></p>
                </div>

                <div class="yourordersitemheaderitem">
                    <p class="mb-0">ORDER ID</p>
                    <p class="mb-0"># <?php echo e($order->id); ?></p>
                </div>

                <div class="yourordersitemheaderitem1">
                    <a href="<?php echo e(route('orders.invoice', $order)); ?>" class="mb-0 text-primary invoicedownloadlink">
                    <span id="invoicedownloadicon" class="material-icons d-block">
                        file_download
                    </span>
                    <span class="d-block">
                        Invoice
                    </span>
                    </a>
                </div>
            </div>

            <div class="yourordersitembody">
                <div id="yourordersitembody1">
                    <p class="yourordersdelivereddate"><strong>Order Placed <?php echo e(date('d M, Y', strtotime($order->created_at))); ?></strong></p>

                    <?php $__empty_2 = true; $__currentLoopData = $order->orderProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderproduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>    
                        <div class="yourordersproduct">
                            <div class="yourordersproductimg">
                                <img src="<?php echo e(asset('images/'.$orderproduct->product->image)); ?>" alt="">
                            </div>

                            <div class="yourordersproductinfo">
                                <p class="mb-0 yourordersprodname"><?php echo e($orderproduct->product->name); ?></p>
                                <p class="mb-2 text-secondary yourordersprodname small">Variant : <?php echo e($orderproduct->varient->name); ?></p>
                                <p class="mb-2 text-secondary small">Qty: <?php echo e($orderproduct->quantity); ?></p>
                                <?php if($orderproduct->returned): ?>
                                    <p class="mb-2 text-danger small">This product is returned</p>
                                <?php endif; ?>
                                <button class="btn bluebg mb-3" onclick="location.href='<?php echo e(route('products.show', $orderproduct->product)); ?>'">Buy Again</button>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                        
                    <?php endif; ?>

                </div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cancel', $order)): ?>
                    <div id="yourordersitembody2">
                        <a href="<?php echo e(route('orders.cancel', $order)); ?>" class="btn btn-outline-danger">Cancel
                        Delivery</a>
                    </div>
                <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('return', $order)): ?>
                    <div id="yourordersitembody2">
                        <a href="<?php echo e(route('orders.return.create', $order)); ?>" class="btn btn-outline-danger">Return
                        Items</a>
                        <p class="mb-0 text-secondary verysmall">You can return order within 8 days of delivery date.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <p>You don't placed any order</p>
      <?php endif; ?>

    </div>
    <!-- your orders end -->
  </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['header' => 'small', 'footer' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adina\Desktop\skyline\resources\views/orders/index.blade.php ENDPATH**/ ?>