

<?php $__env->startSection('ogtitle', 'Skyline Distributors | Aurangabad'); ?>
<?php $__env->startSection('title', 'Bulk Quotes'); ?>

<?php $__env->startSection('content'); ?>
    <!-- breadcrumb start -->
    <nav id="breadcrumbproductinfo" style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
        <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="index.html">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">All Bulk Quote Requests</li>
        </ol>
    </nav>
    <!-- breadcrumb ends -->


    <style>
        .allyourquotescont {
        padding: 1.2rem;

        }

        .downloadskylinepdf {
        display: flex;
        justify-content: start;
        align-items: center;
        }

        .downloadskylinepdf span {
        font-size: 13px;
        color: var(--blue);
        }

        .downloadskylinepdf .material-icons {
        font-size: 22px;
        margin-right: 2px;
        }

        #downloadquottext:hover {
        text-decoration: underline var(--blue);
        }

        .allyourquotedate {
        font-style: italic;
        color: grey;
        font-size: 14px;
        font-weight: 550;
        }
    </style>


    <!-- bulk quotes starts -->
    <section>
        <div class="allyourquotescont">
            <p class="mb-2 fw-bold">Total Quotes : <?php if($quotes): ?> <?php echo e(count($quotes)); ?> <?php else: ?> 0 <?php endif; ?></p>
        </div>

        <?php $__empty_1 = true; $__currentLoopData = $quotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="allyourquotescont">
                <div class="allyourquoteitem card p-2 mt-3 mb-3">
                    <div class="allyourquotedate">
                    <p class=""><?php echo e(date('d M, Y', strtotime($quote->created_at))); ?></p>
                    </div>

                    <div class="mb-3">
                    <label class="form-label small">Your Quote Request :</label>
                    <textarea class="form-control form-control-sm" id="exampleFormControlTextarea1" rows="5" disabled><?php echo e($quote->requirement); ?></textarea>
                    </div>

                    <?php if($quote->clientQuotationFile): ?> 
                        <a href="<?php echo e(asset('files/'.$quote->clientQuotationFile )); ?>">
                        <div class="downloadskylinepdf">
                            <span class="material-icons">
                            file_download
                            </span>
                            <span id="downloadquottext">
                            Download Your Quotation
                            </span>
                        </div>
                        </a>
                    <?php endif; ?>


                    <div class="mb-3 mt-4">
                    <label class="form-label small">Skyline's Reply :</label>
                    <p > <?php echo $quote->reply; ?> </p>
                    </div>

                    <?php if($quote->adminQuotationFile): ?> 
                        <a href="<?php echo e(asset('files/'.$quote->adminQuotationFile )); ?>">
                        <div class="downloadskylinepdf">
                            <span class="material-icons">
                            file_download
                            </span>
                            <span id="downloadquottext">
                            Download Skyline's Quotation
                            </span>
                        </div>
                        </a>
                    <?php endif; ?>

                </div>
            </div>
            <div class="b-example-divider"></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            
        <?php endif; ?>




    </section>
    <!-- bulk quotes ends -->
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['header' => 'small', 'footer' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\adina\Desktop\skyline\resources\views/quotes/index.blade.php ENDPATH**/ ?>