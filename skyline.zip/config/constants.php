<?php return [
    'userType' =>  [
        'user' => 'user',
        'admin' => 'admin'
    ],
    'orderStatus' => [
        'ordered' => 'ordered',
        'cancelled' => 'cancelled',
        'accepted' => 'accepted',
        'packed' => 'packed',
        'shipped' => 'shipped',
        'outForDelivery' => 'outForDelivery',
        'delivered' => 'delivered',
        'returned' => 'returned',
    ]
];
